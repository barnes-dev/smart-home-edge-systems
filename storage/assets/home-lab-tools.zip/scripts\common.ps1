# ============================================================================
# HOME LAB DOCUMENTATION BUILD PIPELINE
# common.ps1
#
# Maintained for Smart-Home-Edge-Systems.us by ChatGPT.
# Release 1.2
# ============================================================================
#
# PURPOSE
# -------
# Shared logging, console-output, and required-path helpers.
#
# RELEASE 1.2 NOTES
# -----------------
# * Updated release header from 1.1 to 1.2.
# * Existing logging behavior is preserved.
# * Debug messages are written to the log even when hidden from the console.
# ============================================================================

$global:BuildLogPath = $null
$global:DebugMode    = $false

function Set-BuildLogFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $false)]
        [bool]$EnableDebug = $false,

        [Parameter(Mandatory = $false)]
        [switch]$ClearLog = $true
    )

    $LogDir = [System.IO.Path]::GetDirectoryName($Path)

    if (-not [string]::IsNullOrEmpty($LogDir) -and -not (Test-Path -LiteralPath $LogDir)) {
        New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    }

    if ($ClearLog) {
        Set-Content -Path $Path -Value "" -ErrorAction SilentlyContinue
    }

    $global:BuildLogPath = $Path
    $global:DebugMode    = $EnableDebug
}

function Write-BuildLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$Message,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Info", "Success", "Warning", "Error", "Header", "Detail", "Debug")]
        [string]$Level = "Info"
    )

    $TimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $FormattedLogMessage = "[$TimeStamp] [$($Level.ToUpper())] $Message"

    $ShowInConsole = $true

    if ($Level -eq "Debug" -and -not $global:DebugMode) {
        $ShowInConsole = $false
    }

    if ($ShowInConsole) {
        switch ($Level) {
            "Header"  { Write-Host "`n=== $Message ===" -ForegroundColor White -BackgroundColor DarkBlue }
            "Success" { Write-Host "[OK] $Message" -ForegroundColor Green }
            "Warning" { Write-Host "[WARN] $Message" -ForegroundColor Yellow }
            "Error"   { Write-Host "[FAIL] $Message" -ForegroundColor Red }
            "Detail"  { Write-Host "     $Message" -ForegroundColor DarkCyan }
            "Debug"   { Write-Host "[DEBUG] $Message" -ForegroundColor Gray }
            Default   { Write-Host "--> $Message" -ForegroundColor Cyan }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($global:BuildLogPath)) {
        $FormattedLogMessage | Out-File -FilePath $global:BuildLogPath -Append -Encoding utf8
    }
}

function Write-BuildBlock {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Title
    )

    Write-Host ""
    Write-Host "======================================================================" `
        -ForegroundColor DarkGray

    Write-Host $Title `
        -ForegroundColor White `
        -BackgroundColor DarkBlue

    Write-Host "======================================================================" `
        -ForegroundColor DarkGray
}

function Write-BuildInfo {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    Write-Host "--> $Message" -ForegroundColor Cyan
}

function Write-BuildSuccess {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    Write-Host "--> $Message" -ForegroundColor Green
}

function Write-BuildWarning {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    Write-Host "--> $Message" -ForegroundColor Yellow
}

function Write-BuildError {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    Write-Error $Message
}

function Test-RequiredPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Required $Description not found: $Path"
    }

    return $true
}
