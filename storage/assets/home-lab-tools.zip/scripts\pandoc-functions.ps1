# ============================================================================
# PANDOC FUNCTIONS
# ============================================================================
#
# Maintained for Smart-Home-Edge-Systems.us
# Release 1.2
#
# PURPOSE
# -------
# Isolates Pandoc operations.
#
# RELEASE 1.2
# -----------
# * Normal DOCX -> Markdown remains separate from index conversion.
# * Index DOCX <-> HTML conversion is explicit and does not enter the normal
#   Markdown/TextBlock/media pipeline.
# * Normalize-MarkdownMedia is intentionally NOT defined here. The authoritative
#   implementation lives in asset-functions.ps1.
# ============================================================================

function Convert-DocxToMarkdown {
    param(
        [Parameter(Mandatory = $true)][string]$InputDocx,
        [Parameter(Mandatory = $true)][string]$OutputMarkdown,
        [Parameter(Mandatory = $true)][string]$AssetDirectory
    )

    if (-not (Get-Command pandoc -ErrorAction SilentlyContinue)) {
        throw "Pandoc was not found in PATH."
    }

    if (-not (Test-Path -LiteralPath $InputDocx)) {
        throw "Input DOCX not found: $InputDocx"
    }

    if (-not (Test-Path -LiteralPath $AssetDirectory)) {
        New-Item -ItemType Directory -Path $AssetDirectory -Force | Out-Null
    }

    pandoc `
        $InputDocx `
        -f "docx+styles" `
        -t "markdown+bracketed_spans" `
        "--extract-media=$AssetDirectory" `
        --wrap=none `
        -o $OutputMarkdown

    $ExitCode = $LASTEXITCODE

    if ($ExitCode -ne 0) {
        throw "Pandoc DOCX to Markdown failed with exit code $ExitCode."
    }

    if (-not (Test-Path -LiteralPath $OutputMarkdown)) {
        throw "Pandoc did not create Markdown output: $OutputMarkdown"
    }

    $Utf8NoBom = [System.Text.UTF8Encoding]::new($false)
    $mdContent = [System.IO.File]::ReadAllText($OutputMarkdown, $Utf8NoBom)

    # IMPORTANT:
    # Do not remove custom-style fences here.
    #
    # TextBlock conversion is performed by Normalize-MarkdownMedia in
    # asset-functions.ps1. Removing the fences at this point would destroy
    # the marker that identifies a TextBlock and would reintroduce the
    # intermittent "TextBlock missing" failure this Release is intended
    # to address.
    #
    # Pandoc output is therefore written unchanged at this stage.
    [System.IO.File]::WriteAllText(
        $OutputMarkdown,
        $mdContent,
        $Utf8NoBom
    )
}

function Convert-MarkdownToHtml {
    param(
        [Parameter(Mandatory = $true)][string]$MarkdownFile,
        [Parameter(Mandatory = $true)][string]$OutputHtml,
        [Parameter(Mandatory = $true)][string]$TemplateFile,
        [Parameter(Mandatory = $true)][string]$LuaFilter,
        [Parameter(Mandatory = $true)][string]$Title
    )

    if (-not (Get-Command pandoc -ErrorAction SilentlyContinue)) {
        throw "Pandoc was not found in PATH."
    }
    if (-not (Test-Path -LiteralPath $MarkdownFile)) {
        throw "Markdown file not found: $MarkdownFile"
    }
    if (-not (Test-Path -LiteralPath $TemplateFile)) {
        throw "Pandoc template not found: $TemplateFile"
    }
    if (-not (Test-Path -LiteralPath $LuaFilter)) {
        throw "Pandoc Lua filter not found: $LuaFilter"
    }

    $Arguments = @(
        $MarkdownFile,
        "-f", "markdown+bracketed_spans-tex_math_dollars-raw_tex",
        "-t", "html5",
        "--quiet",  # <--- ADD THIS EXACT LINE HERE
        "--template=$TemplateFile",
        "--metadata", "title=$Title",
        "--standalone",
        "--toc",
        "--toc-depth=4",
        "--id-prefix=nav-",
        "--lua-filter=$LuaFilter",
        "-o", $OutputHtml
    )

    pandoc @Arguments
    $ExitCode = $LASTEXITCODE
    if ($ExitCode -ne 0) {
        throw "Pandoc Markdown to HTML failed with exit code $ExitCode."
    }
    if (-not (Test-Path -LiteralPath $OutputHtml)) {
        throw "Pandoc did not create HTML output: $OutputHtml"
    }
}
function Convert-IndexDocxToHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$InputDocx,
        [Parameter(Mandatory = $true)][string]$OutputHtml,
        [Parameter(Mandatory = $true)][string]$TemplateFile,
        [Parameter(Mandatory = $true)][string]$Title = "Smart Home Edge Systems"
    )

    if (-not (Get-Command pandoc -ErrorAction SilentlyContinue)) {
        throw "Pandoc was not found in PATH."
    }

    if (-not (Test-Path -LiteralPath $InputDocx)) {
        throw "Index DOCX not found: $InputDocx"
    }

    if (-not (Test-Path -LiteralPath $TemplateFile)) {
        throw "Pandoc template not found: $TemplateFile"
    }

    $OutputDirectory = Split-Path -Parent $OutputHtml

    if (-not (Test-Path -LiteralPath $OutputDirectory)) {
        New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    }

    pandoc `
        $InputDocx `
        -o $OutputHtml `
        --from docx `
        --to html `
        --template $TemplateFile `
        --metadata "title=$Title"

    $ExitCode = $LASTEXITCODE

    if ($ExitCode -ne 0) {
        throw "Pandoc index DOCX -> HTML failed with exit code $ExitCode."
    }

    if (-not (Test-Path -LiteralPath $OutputHtml)) {
        throw "Pandoc did not create index HTML: $OutputHtml"
    }
}

function Convert-IndexHtmlToDocx {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$InputHtml,
        [Parameter(Mandatory = $true)][string]$OutputDocx,
        [Parameter(Mandatory = $true)][string]$ResourceRoot
    )

    if (-not (Get-Command pandoc -ErrorAction SilentlyContinue)) {
        throw "Pandoc was not found in PATH."
    }

    if (-not (Test-Path -LiteralPath $InputHtml)) {
        throw "Index HTML not found: $InputHtml"
    }

    $OutputDirectory = Split-Path -Parent $OutputDocx

    if (-not (Test-Path -LiteralPath $OutputDirectory)) {
        New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    }

    pandoc `
        $InputHtml `
        -o $OutputDocx `
        --from html `
        --to docx `
        --resource-path "$((Get-Item -LiteralPath $InputHtml).DirectoryName);$ResourceRoot"

    $ExitCode = $LASTEXITCODE

    if ($ExitCode -ne 0) {
        throw "Pandoc index HTML -> DOCX failed with exit code $ExitCode."
    }

    if (-not (Test-Path -LiteralPath $OutputDocx)) {
        throw "Pandoc did not create index DOCX: $OutputDocx"
    }
}

function Get-CssRelPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SiteRelativeHtmlPath
    )

    $HtmlPath = $SiteRelativeHtmlPath.Replace('\', '/')
    $HtmlDir  = Split-Path $HtmlPath -Parent
    $Depth    = if ($HtmlDir) { ($HtmlDir -split '/').Count } else { 0 }
    $RelUp    = "../" * $Depth

    return "${RelUp}styles/global.css"
}
