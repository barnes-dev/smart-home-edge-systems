#Reverse DOCX to HTML

$SourceRoot = "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\site-documentation"
$TargetRoot = "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\smart-home-edge-systems"
$Pandoc = "C:\Program Files\Pandoc\pandoc.exe"
$Template = "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\home-lab-project\templates\template.html"
$GtmFile = "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\home-lab-project\templates\googletagmanager.txt"

$Gtm = Get-Content -LiteralPath $GtmFile -Raw

Get-ChildItem $SourceRoot -Filter "index.docx" -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($SourceRoot.Length).TrimStart("\")
    $rel = $rel -replace "\\index\.docx$", "\index.html"

    $htmlOut = Join-Path $TargetRoot $rel
    New-Item -ItemType Directory -Path (Split-Path $htmlOut) -Force | Out-Null

    & $Pandoc $_.FullName `
        -o $htmlOut `
        --from docx `
        --to html `
        --template $Template `
        --metadata title="Smart Home Edge Systems"

    if ($LASTEXITCODE -ne 0) {
        throw "Pandoc failed for $($_.FullName)"
    }

    $content = Get-Content -LiteralPath $htmlOut -Raw

    if ($content -notmatch [regex]::Escape($Gtm.Trim())) {
        $content = $content.Replace("</head>", "$Gtm`r`n</head>")
        Set-Content -LiteralPath $htmlOut -Value $content -Encoding UTF8 -NoNewline
    }

    Write-Host "Recreated: $htmlOut"
}

#Reverse HTML to DOCX

$SourceRoot = "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\smart-home-edge-systems"
$TargetRoot = "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\site-documentation"
$Pandoc = "C:\Program Files\Pandoc\pandoc.exe"

Get-ChildItem `
    -LiteralPath $SourceRoot `
    -Filter "index.html" `
    -Recurse `
    -File |
ForEach-Object {
    $sourceFile = $_
    $relativePath = $sourceFile.FullName.Substring($SourceRoot.Length).TrimStart("\")
    $targetFile = Join-Path $TargetRoot $relativePath
    $targetFile = [IO.Path]::ChangeExtension($targetFile, ".docx")

    New-Item `
        -ItemType Directory `
        -Path (Split-Path -Parent $targetFile) `
        -Force |
        Out-Null

    & $Pandoc `
        $sourceFile.FullName `
        -o $targetFile `
        --from html `
        --to docx `
        --resource-path "$($sourceFile.DirectoryName);$SourceRoot"

    if ($LASTEXITCODE -ne 0) {
        throw "Pandoc failed for: $($sourceFile.FullName)"
    }

    Write-Host "Created: $targetFile"
}

