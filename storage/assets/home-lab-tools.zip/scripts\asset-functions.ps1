# ============================================================================
# ASSET FUNCTIONS
# ============================================================================
#
# Maintained for Smart-Home-Edge-Systems.us by ChatGPT.
# Release 1.2
#
# PURPOSE
# -------
# Handles extracted images, asset naming, Markdown media normalization,
# temporary media directories, and ZIP files.
#
# RELEASE 1.2 DESIGN
# ------------------
# Normalize-MarkdownMedia is authoritative in this module.
# Do NOT define another function with the same name in pandoc-functions.ps1.
# ============================================================================

function Get-ExtractedMediaDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$AssetDirectory
    )

    return (Join-Path $AssetDirectory "media")
}

function Get-ExtractedMediaFiles {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MediaDirectory
    )

    if (-not (Test-Path -LiteralPath $MediaDirectory)) {
        return @()
    }

    return @(Get-ChildItem `
        -Path $MediaDirectory `
        -File |
        Sort-Object Name)
}

function New-AssetArchive {
    param(
        [Parameter(Mandatory = $true)]
        [string]$AssetDirectory,

        [Parameter(Mandatory = $true)]
        [string]$ArchivePath
    )

    $Files = Get-ChildItem `
        -Path $AssetDirectory `
        -File |
        Where-Object { $_.FullName -ne $ArchivePath }

    if (-not $Files) {
        return $false
    }

    if (Test-Path -LiteralPath $ArchivePath) {
        Remove-Item -LiteralPath $ArchivePath -Force
    }

    Compress-Archive `
        -Path $Files.FullName `
        -DestinationPath $ArchivePath `
        -Force

    return (Test-Path -LiteralPath $ArchivePath)
}

function Remove-TemporaryMediaDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MediaDirectory
    )

    if (Test-Path -LiteralPath $MediaDirectory) {
        Remove-Item `
            -LiteralPath $MediaDirectory `
            -Recurse `
            -Force
    }
}

function Normalize-MarkdownMedia {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$MarkdownFile,

        [Parameter(Mandatory = $true)]
        [string]$BaseName
    )

    if (-not (Test-Path -LiteralPath $MarkdownFile)) {
        Write-BuildLog "Normalize-MarkdownMedia: Markdown file not found at '$MarkdownFile'." -Level Warning
        return
    }

    Write-BuildLog "Normalizing media links and TextBlocks in Markdown file: $MarkdownFile" -Level Debug

    $sr = [System.IO.StreamReader]::new($MarkdownFile, $true)
    try {
        $Content = $sr.ReadToEnd()
    }
    finally {
        $sr.Close()
    }

    # ------------------------------------------------------------------------
    # 1. Normalize image paths.
    # ------------------------------------------------------------------------
    $UpdatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $Content,
        '(!\[.*?\]\()(.+?[\\/])?([^\\/]+\.(png|jpg|jpeg|gif|svg|webp))(\))',
        '$1../figures/$3$5',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    # ------------------------------------------------------------------------
    # 2. Normalize Pandoc image + definition-list caption pairs.
    #
    # This converts:
    #     ![alt](image)
    #     : Caption
    #
    # into:
    #     ![Figure N: Caption](image)
    #
    # The operation is performed once per matched image/caption pair.
    # ------------------------------------------------------------------------
    $FigureCounter = 0

    $CombinedPattern = '(?ms)(?:!\[(.*?)\]\(([^)]+)\)(\{[^}]+\})?)\s*\r?\n+\s*:\s*(.+?)(?=\r?\n\r?\n|\z)'

    $MatchesList = [System.Text.RegularExpressions.Regex]::Matches(
        $UpdatedContent,
        $CombinedPattern
    )

    foreach ($Match in $MatchesList) {
        $AltText     = $Match.Groups[1].Value.Trim()
        $ImagePath   = $Match.Groups[2].Value.Trim()
        $ImageAttrs  = $Match.Groups[3].Value
        $CaptionText = $Match.Groups[4].Value.Trim()

        $CaptionText = $CaptionText -replace '\[.*?\]\{custom-style=.*?\}', ''
        $CaptionText = $CaptionText -replace '^(Figure\s*\d+[:\s-]*)', ''
        $CaptionText = $CaptionText.Trim()

        $FigureCounter++
        $Replacement = "![Figure ${FigureCounter}: ${CaptionText}](${ImagePath})${ImageAttrs}"

        $UpdatedContent = $UpdatedContent.Replace(
            $Match.Value,
            $Replacement
        )
    }

    # ------------------------------------------------------------------------
    # 3. TextBlock normalization.
    #
    # Pandoc can emit a fenced custom-style block:
    #
    # ::: {custom-style="TextBlock"}
    # content
    # :::
    #
    # Convert the entire block into a one-cell Markdown table. The delimiters
    # are removed, so the TextBlock content remains actual document content.
    #
    # IMPORTANT:
    #   Do not use a nested pipeline or a second Normalize-MarkdownMedia
    #   implementation. This is the single authoritative implementation.
    # ------------------------------------------------------------------------
    $TextBlockPattern = '(?ms)^\s*:::\s*\{custom-style=["“”]?TextBlock["“”]?\}\s*\r?\n(.*?)\r?\n\s*:::\s*$'

    $UpdatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $UpdatedContent,
        $TextBlockPattern,
        {
            param($Match)

            $Inner = $Match.Groups[1].Value.Trim()

            if ([string]::IsNullOrWhiteSpace($Inner)) {
                return ""
            }

            # Preserve multiline TextBlock content as a single table cell.
            # HTML/CSS will handle the resulting table presentation.
            $Escaped = $Inner -replace '\|', '\|'
            return "|`r`n|---|`r`n| $Escaped |`r`n|---|"
        }
    )

    # ------------------------------------------------------------------------
    # 4. Remove empty custom-style fences left by Pandoc.
    # ------------------------------------------------------------------------
    $UpdatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $UpdatedContent,
        '(?m)^\s*:::\s*\{custom-style=.*?\}\s*$',
        ''
    )

    $UpdatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $UpdatedContent,
        '(?m)^\s*:::\s*$',
        ''
    )

    [System.IO.File]::WriteAllText(
        $MarkdownFile,
        $UpdatedContent,
        [System.Text.UTF8Encoding]::new($false)
    )

    Write-BuildLog "Normalized Markdown media/TextBlocks: $MarkdownFile" -Level Debug
}
