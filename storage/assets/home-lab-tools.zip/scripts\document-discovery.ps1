# ============================================================================
# DOCUMENT DISCOVERY
# ============================================================================
#
# Home Lab Documentation Build Pipeline
# Maintained for Smart-Home-Edge-Systems.us by ChatGPT
# Release 1.2
#
# PURPOSE
# -------
# Locate normal DOCX source documents for the documentation build pipeline.
#
# IMPORTANT
# ---------
# index.docx is intentionally excluded from normal document discovery.
# Index files are maintained by the dedicated IndexMode workflow in build.ps1.
# This prevents index documents from entering the normal:
#
#     DOCX -> Markdown -> media/TextBlock normalization -> HTML
#
# pipeline.
# ============================================================================

function Get-BuildDocuments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProjectRoot,

        [Parameter(Mandatory = $false)]
        [string]$DocBaseName = $null,

        [Parameter(Mandatory = $false)]
        [ValidateSet("guides", "reference")]
        [string]$TargetFolder = $null
    )

    $SearchDirectories = @()

    if ($TargetFolder) {
        $TargetPath = Join-Path $ProjectRoot $TargetFolder

        if (Test-Path -LiteralPath $TargetPath) {
            $SearchDirectories += $TargetPath
        }
    }
    else {
        $GuidesPath    = Join-Path $ProjectRoot "guides"
        $ReferencePath = Join-Path $ProjectRoot "reference"

        if (Test-Path -LiteralPath $GuidesPath) {
            $SearchDirectories += $GuidesPath
        }

        if (Test-Path -LiteralPath $ReferencePath) {
            $SearchDirectories += $ReferencePath
        }
    }

    $Documents = @()

    foreach ($SearchDirectory in $SearchDirectories) {
        if ($DocBaseName) {
            # A specifically requested index.docx is still excluded.
            if ($DocBaseName -ieq "index") {
                continue
            }

            $Candidate = Join-Path $SearchDirectory "$DocBaseName.docx"

            if (Test-Path -LiteralPath $Candidate) {
                $Documents += Get-Item -LiteralPath $Candidate
            }
        }
        else {
            $Documents += Get-ChildItem `
                -LiteralPath $SearchDirectory `
                -Filter "*.docx" `
                -File `
                -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -ine "index.docx" }
        }
    }

    $Documents |
        Sort-Object FullName -Unique
}
