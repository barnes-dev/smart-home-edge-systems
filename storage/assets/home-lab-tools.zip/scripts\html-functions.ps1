# ============================================================================
# HTML FUNCTIONS
# ============================================================================
#
# Home Lab Documentation Build Pipeline
# Maintained for Smart-Home-Edge-Systems.us by ChatGPT
# Release 1.2
#
# PURPOSE
# -------
# HTML cleanup and normalization functions for the NORMAL documentation
# pipeline.
#
# INDEX RULE
# ----------
# index.html is intentionally not passed through Normalize-Html. Index files
# are generated/converted by the dedicated IndexMode workflow.
# ============================================================================

function Normalize-HtmlLabels {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Html
    )

    # Use local closure variables instead of $script: variables. This keeps
    # separate invocations deterministic and prevents counter state leaking
    # between documents.
    $FigureIndex = 0
    $TableIndex  = 0
    $CodeIndex   = 0

    $Html = [regex]::Replace($Html, '\bFigure(?:\s*|&nbsp;)*\d*:', {
        param($Match)
        $FigureIndex++
        "Figure ${FigureIndex}:"
    })

    $Html = [regex]::Replace($Html, '\bTable(?:\s*|&nbsp;)*\d*:', {
        param($Match)
        $TableIndex++
        "Table ${TableIndex}:"
    })

    $Html = [regex]::Replace($Html, '\bCode(?:\s*|&nbsp;)*\d*:', {
        param($Match)
        $CodeIndex++
        "Code ${CodeIndex}:"
    })

    return $Html
}

function Save-NormalizedHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$InputPath,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath
    )

    if (-not (Test-Path -LiteralPath $InputPath)) {
        throw "HTML input file not found: $InputPath"
    }

    $Html = Get-Content `
        -LiteralPath $InputPath `
        -Raw `
        -ErrorAction Stop

    $Html = Normalize-HtmlLabels -Html $Html

    $OutputDirectory = Split-Path -Parent $OutputPath

    if (-not (Test-Path -LiteralPath $OutputDirectory)) {
        New-Item `
            -ItemType Directory `
            -Path $OutputDirectory `
            -Force |
            Out-Null
    }

    Set-Content `
        -LiteralPath $OutputPath `
        -Value $Html `
        -Encoding UTF8 `
        -ErrorAction Stop
}

function Normalize-Html {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$HtmlFile,

        [Parameter(Mandatory = $false)]
        [string]$BaseName = ""
    )

    if (-not (Test-Path -LiteralPath $HtmlFile)) {
        throw "HTML file not found: $HtmlFile"
    }

    # Explicitly reject index.html so accidental normal-pipeline invocation
    # cannot silently modify an index.
    if ((Split-Path -Leaf $HtmlFile) -ieq "index.html") {
        throw "Normalize-Html does not process index.html. Use IndexMode instead."
    }

    $Content = Get-Content -LiteralPath $HtmlFile -Raw -Encoding UTF8

    if (-not [string]::IsNullOrWhiteSpace($BaseName)) {
        $Content = [regex]::Replace(
            $Content,
            'src="[^"]*?[\\/]figures[\\/]([^"]+)"',
            'src="' + "$BaseName/media/" + '$1"'
        )
    }

    Set-Content -LiteralPath $HtmlFile -Value $Content -Encoding UTF8

    Write-BuildLog "Normalized HTML: $HtmlFile" -Level Debug
}
