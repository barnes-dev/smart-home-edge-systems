<#
=============================================================================
HOME LAB DOCUMENTATION BUILD PIPELINE � EXECUTION FLOW
=============================================================================

MAIN SEQUENCE (runs once):
  Block 1 INITIALIZE          ? Load common.ps1, configure logging
  Block 2 BASE PATHS          ? Define $ProjectRoot, $DocBasePath, $DeployRoot
  Block 3 DISCOVER DOCUMENTS  ? Parse args, build $Documents collection
    MODE A: -Document "site\folder\file.docx"
    MODE B: -DocBaseName -TargetFolder
    MODE C: Batch mode (no document specified)
  Block 4 DEFINE PATHS        ? Resolve all derived paths using discovered vars
  Block 5 VALIDATE STRUCTURE  ? Verify required directories exist
  Block 6 LOAD LIBRARIES      ? Import modular function libraries
  Block 7 MODEL CONFIG        ? Configure AI/model settings (optional)
  Block 8 REPORT DOCUMENTS    ? Log discovered document queue

  Block 9 PER-DOCUMENT LOOP (runs for each item in $Documents):
    -----------------------------------------------------------------------
     TITLE TRANSFORMATION               (Remove leading numbers, strip hyphens, Title Case)
     PER-DOCUMENT PATHS
     STAGE 1: DOCX ? MARKDOWN           (Convert-DocxToMarkdown)
     STAGE 2: MARKDOWN MEDIA NORMALIZE  (Normalize-MarkdownMedia)
     STAGE 3: MARKDOWN ? HTML           (Convert-MarkdownToHtml)
     STAGE 4: HTML NORMALIZATION        (Normalize-Html)
       INJECT TOOL BUNDLE LINK          (install guide only)
     STAGE 5: PREPARE DEPLOY DIRS       (New-Item -Force)
     STAGE 6: DEPLOY HTML & MEDIA       (Copy-Item)
     STAGE 7: ARCHIVE PACKAGING         (Compress-Archive)
    -----------------------------------------------------------------------

  Block 10 POST-PROCESSING (runs once after loop):
  Block 11 TOOL BUNDLE & CLEANUP ? Create home-lab-tools.zip, clean artifacts
=============================================================================
#>

# ============================================================================
# PARAMETER DEFINITION
# ============================================================================
[CmdletBinding()]
param(
    # ------------------------------------------------------------------------
    # Optional document path in format: SiteName\TargetFolder\FileName.docx
    #
    # Examples:
    #
    #   # Process ALL .docx in guides\ and reference\ (batch mode, default site: homelab)
    #   .\build.ps1
    #
    #   # Process single document .docx in locations specified (fully qualified)
    #   .\build.ps1 -Document "storage\guides\2-ProxmoxStorageServerInstallGuide.docx"
    #
    #   # Process ALL .docx in guides\ and reference\ for custom site
    #   .\build.ps1 -SiteName "home-assistant"
    #
    #   # Single document, default site (homelab) - custom Target
    #   .\build.ps1 -TargetFolder "guides" -DocBaseName "1-home-lab-install-procedure"
    #
    #   # Single document, custom site and Target
    #   .\build.ps1 -SiteName "home-assistant" -TargetFolder "guides" -DocBaseName "1-home-lab-install-procedure"
    #
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false, Position = 0)]
    [string]$Document = $null,

    # ------------------------------------------------------------------------
    # Optional source filename without extension.
    # extensions are assumed as follows:
    # .doc - Source Word Document
    # .pdf - PDF created by Word Save and publish macro
    # .md - created as internal step by buils.ps1 using pandoc
    # .html - created by build.psa via pandox as the final product to be published
    # For example "1-home-lab-install-procedure"
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false)]
    [string]$DocBaseName = $null,

    # ------------------------------------------------------------------------
    # Optional source folder.
    #
    # Valid values:
    #     guides
    #     reference
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false)]
    [ValidateSet("guides", "reference")]
    [string]$TargetFolder = $null,

    # ------------------------------------------------------------------------
    # Site subfolder under smart-home-edge-systems
    # Valid values:
    #
    #     homelab (default)
    #     home-assistant
    #     3d-printing
    #     marketing
    #     r-d
    #     storage
    #     surveillance
    #     voice
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false)]
    [ValidateSet("homelab", "home-assistant", "3d-printing", "marketing", "r-d", "storage", "surveillance", "voice")]
    [string]$SiteName = "homelab",

    # ------------------------------------------------------------------------
    # Enables the future model-review stage.
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false)]
    [switch]$RunModel,

    # ------------------------------------------------------------------------
    # Enables AI-powered document review using Gemini CLI.
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false)]
    [switch]$UseAIReview,

    # ------------------------------------------------------------------------
    # Sends Logfile output to the console.
    # ------------------------------------------------------------------------
    [Parameter(Mandatory = $false)]
    [switch]$DebugMode
)

# ============================================================================
# HELPER: SPLIT DOCUMENT PATH
# ============================================================================
function Split-DocumentPath {
    param([string]$Path)
    $parts = $Path -split '[\\/]'
    if ($parts.Count -lt 3) { throw "Path must be SiteName\TargetFolder\FileName.ext" }
    return @{
        SiteName     = $parts[0]
        TargetFolder = $parts[1]
        DocBaseName  = [IO.Path]::GetFileNameWithoutExtension($parts[2])
        Extension    = [IO.Path]::GetExtension($parts[2]).TrimStart('.')
        FileName     = $parts[2]
    }
}

# ============================================================================
# Block 1 INITIALIZE � Load common.ps1, configure logging
# ============================================================================
. (Join-Path $PSScriptRoot "scripts\common.ps1")
Set-BuildLogFile -Path (Join-Path $PSScriptRoot "build\logs\build.log") -EnableDebug ($DebugMode.IsPresent) -ClearLog

$BuildVersion = "1.1"
Write-BuildLog "HOME LAB DOCUMENTATION BUILD PIPELINE" -Level Header
Write-BuildLog "Maintained for Smart-Home-Edge-Systems.us" -Level Debug
Write-BuildLog "Release: $BuildVersion" -Level Debug

# ============================================================================
# Block 2 BASE PATHS � Define static repository roots ($ProjectRoot, $DocBasePath, $DeployRoot)
# ============================================================================
$ProjectRoot = $PSScriptRoot
Write-BuildLog "BASE PATHS � Project root: $ProjectRoot" -Level Debug

$DocBasePath = [IO.Path]::GetFullPath((Join-Path $ProjectRoot "..\site-documentation"))
$DeployRoot  = [IO.Path]::GetFullPath((Join-Path $ProjectRoot "..\smart-home-edge-systems"))

Write-BuildLog "  DocBasePath: $DocBasePath" -Level Debug
Write-BuildLog "  DeployRoot:  $DeployRoot" -Level Debug

# ============================================================================
# Block 3 DISCOVER DOCUMENTS � Parse args, populate $Documents collection, set $SiteName/$TargetFolder/$DocBaseName
# ============================================================================
Write-BuildLog "DISCOVER DOCUMENTS" -Level Debug
$Documents = @()

# MODE A: -Document "site\folder\file.docx"
if ($Document) {
    Write-BuildLog "Mode: Single document via -Document path" -Level Debug
    $doc = Split-DocumentPath -Path $Document
    $SiteName       = $doc.SiteName
    $TargetFolder   = $doc.TargetFolder
    $DocBaseName    = $doc.DocBaseName
    $SourceDocxPath = Join-Path $DocBasePath $Document

    if (-not (Test-Path -LiteralPath $SourceDocxPath)) {
        Write-BuildLog "CRITICAL: Document not found: $SourceDocxPath" -Level Error
        return
    }
    $FileItem = Get-Item -LiteralPath $SourceDocxPath
    $FileItem | Add-Member -MemberType NoteProperty -Name TargetType -Value $TargetFolder -Force
    $Documents = @($FileItem)
    Write-BuildLog "Queued: $($FileItem.Name) [$TargetFolder]" -Level Debug
}

# MODE B: -DocBaseName -TargetFolder
elseif ($DocBaseName -and $TargetFolder) {
    Write-BuildLog "Mode: Single document via -DocBaseName/-TargetFolder" -Level Debug
    $SourceDocxPath = Join-Path $DocBasePath "$SiteName\$TargetFolder\$DocBaseName.docx"

    if (-not (Test-Path -LiteralPath $SourceDocxPath)) {
        Write-BuildLog "CRITICAL: Document not found: $SourceDocxPath" -Level Error
        return
    }
    $FileItem = Get-Item -LiteralPath $SourceDocxPath
    $FileItem | Add-Member -MemberType NoteProperty -Name TargetType -Value $TargetFolder -Force
    $Documents = @($FileItem)
    Write-BuildLog "Queued: $($FileItem.Name) [$TargetFolder]" -Level Debug
}

# MODE C: Batch mode (no document specified)
else {
    Write-BuildLog "Mode: Batch scan $DocBasePath\$SiteName\guides\ and reference\" -Level Debug
    $AllDocuments = @()
    foreach ($Folder in @("guides", "reference")) {
        $FolderPath = Join-Path $DocBasePath "$SiteName\$Folder"
        if (Test-Path -LiteralPath $FolderPath) {
            $Files = Get-ChildItem -Path $FolderPath -Filter "*.docx" -File
            if ($Files) {
                Write-BuildLog "Found $($Files.Count) in $Folder\" -Level Debug
                $AllDocuments += $Files
            }
        }
    }
    if (-not $AllDocuments) {
        Write-BuildLog "No .docx files found in $DocBasePath\$SiteName\" -Level Warning
        return
    }
    $Documents = $AllDocuments | ForEach-Object {
        $_ | Add-Member -MemberType NoteProperty -Name TargetType -Value $_.Directory.Name -PassThru
    }
}

Write-BuildLog "Discovery complete. Total documents: $($Documents.Count)" -Level Success

# ============================================================================
# DEFINE PATHS � Resolve all derived paths using discovered variables
# ============================================================================
Write-BuildLog "DEFINE PATHS" -Level Debug

# Internal workspace
$ConfigDir    = Join-Path $ProjectRoot "config"
$ScriptsDir   = Join-Path $ProjectRoot "scripts"
$PromptsDir   = Join-Path $ProjectRoot "prompts"
$TemplatesDir = Join-Path $ProjectRoot "templates"
$FiltersDir   = Join-Path $ProjectRoot "filters"
$AssetsDir    = Join-Path $ProjectRoot "assets"
$FiguresDir   = Join-Path $AssetsDir "figures"

# Source directories (use resolved $SiteName)
$GuidesDir    = Join-Path $DocBasePath "$SiteName\guides"
$ReferenceDir = Join-Path $DocBasePath "$SiteName\reference"

# Build output (use resolved $DocBaseName)
$MarkdownOut  = Join-Path $ProjectRoot "build\output\${DocBaseName}.md"
$WorkingMedia = Join-Path $ProjectRoot "build\working\$DocBaseName"
$HtmlBuildOut = Join-Path $ProjectRoot "build\output\${DocBaseName}.html"

# Website deployment (use resolved $SiteName, $TargetFolder)
$WebsiteHtml   = Join-Path $DeployRoot "$SiteName\$TargetFolder\${DocBaseName}.html"
$WebsiteMedia  = Join-Path $DeployRoot "$SiteName\$TargetFolder\$DocBaseName\media"
$WebsiteAssets = Join-Path $DeployRoot "$SiteName\$TargetFolder\$DocBaseName\assets"

Write-BuildLog "Resolved paths:" -Level Debug
Write-BuildLog "  SiteName:      $SiteName" -Level Debug
Write-BuildLog "  TargetFolder:  $TargetFolder" -Level Debug
Write-BuildLog "  DocBaseName:   $DocBaseName" -Level Debug
Write-BuildLog "  GuidesDir:     $GuidesDir" -Level Debug
Write-BuildLog "  WebsiteHtml:   $WebsiteHtml" -Level Debug
Write-BuildLog "  WebsiteMedia:  $WebsiteMedia" -Level Debug
Write-BuildLog "  WebsiteAssets: $WebsiteAssets" -Level Debug

# ============================================================================
# VALIDATE STRUCTURE � Verify required directories exist for the resolved site
# ============================================================================
Write-BuildLog "VALIDATE STRUCTURE" -Level Debug

$RequiredDirectories = @(
    $ConfigDir, $ScriptsDir, $PromptsDir, $TemplatesDir, $FiltersDir,
    $GuidesDir, $ReferenceDir, $AssetsDir, $FiguresDir
)

foreach ($dir in $RequiredDirectories) {
    if (-not (Test-Path -LiteralPath $dir)) {
        Write-BuildLog "Missing directory: $dir � creating" -Level Warning
        try { New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null }
        catch { Write-BuildLog "CRITICAL: Cannot create $dir � $_" -Level Error; return }
    }
    Write-BuildLog "Verified: $dir" -Level Debug
}
Write-BuildLog "Structure validation passed" -Level Success

# ============================================================================
# LOAD LIBRARIES � Import modular function libraries
# ============================================================================
Write-BuildLog "LOAD LIBRARIES" -Level Debug

$RequiredScripts = @("common.ps1","document-discovery.ps1","pandoc-functions.ps1","html-functions.ps1","asset-functions.ps1")
$Missing = @()
foreach ($s in $RequiredScripts) {
    $p = Join-Path $ScriptsDir $s
    if (-not (Test-Path $p)) { $Missing += $p }
}
if ($Missing) { Write-BuildLog "Missing scripts: $($Missing -join ', ')" -Level Error; return }

foreach ($mod in @("document-discovery.ps1","pandoc-functions.ps1","html-functions.ps1","asset-functions.ps1")) {
    try {
        . (Join-Path $ScriptsDir $mod)
        Write-BuildLog "Loaded: $mod" -Level Debug
    }
    catch {
        Write-BuildLog "CRITICAL: Failed to load $mod � $_" -Level Error
        return
    }
}
Write-BuildLog "All libraries loaded" -Level Success

# ============================================================================
# Block 7 MODEL CONFIG � Configure AI/model settings
# ============================================================================
Write-BuildLog "MODEL CONFIG" -Level Debug
$ModelProvider = "none"; $ModelName = "none"
if ($RunModel) {
    Write-BuildLog "Model processing requested (disabled in this build)" -Level Debug
} else {
    Write-BuildLog "Model processing disabled" -Level Debug
}
Write-BuildLog "Model config complete" -Level Success

# ============================================================================
# Block 8 REPORT DOCUMENTS � Log discovered queue
# ============================================================================
Write-BuildLog "REPORT DOCUMENTS" -Level Debug
if (-not $Documents) { Write-BuildLog "No documents to process" -Level Warning; return }
foreach ($d in $Documents) { Write-BuildLog "Queued: $($d.FullName)" -Level Debug }
Write-BuildLog "Document queue reported" -Level Success

# ============================================================================
# Block 9 PER-DOCUMENT LOOP � Execute pipeline stages for each document
# ============================================================================
Write-BuildLog "PER-DOCUMENT LOOP START � $($Documents.Count) document(s)" -Level Header

foreach ($DocItem in $Documents) {
    $BaseName   = $DocItem.BaseName
    $DocPath    = $DocItem.FullName
    $TargetType = $DocItem.TargetType   # Set during discovery

    # -------------------------------------------------------------------------
    # TITLE TRANSFORMATION (Remove leading numbers, strip hyphens, Title Case)
    # -------------------------------------------------------------------------
    $CleanTitle = $BaseName -replace '^\d+[-_]?', '' -replace '[-_]', ' '
    $CleanTitle = (Get-Culture).TextInfo.ToTitleCase($CleanTitle.ToLower())

    # -------------------------------------------------------------------------
    # PER-DOCUMENT PATHS
    # -------------------------------------------------------------------------
    $MarkdownOut  = Join-Path $ProjectRoot "build\output\${BaseName}.md"
    $WorkingMedia = Join-Path $ProjectRoot "build\working\$BaseName"
    $HtmlBuildOut = Join-Path $ProjectRoot "build\output\${BaseName}.html"

    $WebsiteHtml  = Join-Path $DeployRoot "$SiteName\$TargetType\${BaseName}.html"
    $WebsiteMedia = Join-Path $DeployRoot "$SiteName\$TargetType\$BaseName\media"

    Write-BuildLog "Processing: $BaseName" -Level Success
    Write-BuildLog "  Processing: $DocPath" -Level Debug
    Write-BuildLog "  Category:    $TargetType" -Level Debug
    Write-BuildLog "  Markdown:    $MarkdownOut" -Level Debug
    Write-BuildLog "  Local Media: $WorkingMedia" -Level Debug
    Write-BuildLog "  Deploy HTML: $WebsiteHtml" -Level Debug
    Write-BuildLog "  Clean Title: $CleanTitle" -Level Debug

    # ========================================================================
    # STAGE 1: DOCX ? MARKDOWN
    # ========================================================================
    Write-BuildLog "STAGE 1 - DOCX ? MARKDOWN" -Level Debug
    Convert-DocxToMarkdown -InputDocx $DocPath -OutputMarkdown $MarkdownOut -AssetDirectory $WorkingMedia
    Write-BuildLog "DOCX to Markdown conversion completed" -Level Debug

    # ========================================================================
    # STAGE 2: MARKDOWN MEDIA NORMALIZATION
    # ========================================================================
    Write-BuildLog "STAGE 2 - MARKDOWN MEDIA NORMALIZATION" -Level Debug
    if (Get-Command Normalize-MarkdownMedia -ErrorAction SilentlyContinue) {
        Normalize-MarkdownMedia -MarkdownFile $MarkdownOut -BaseName $BaseName
        Write-BuildLog "Markdown image references normalized" -Level Debug
    } else {
        Write-BuildLog "Normalize-MarkdownMedia skipped (not loaded)" -Level Debug
    }

    # ========================================================================
    # STAGE 3: MARKDOWN ? HTML
    # ========================================================================
    Write-BuildLog "STAGE 3 - MARKDOWN ? HTML" -Level Debug
    $LuaFilter    = Join-Path $FiltersDir "collapsible-downloads.lua"
    $TemplateFile = Join-Path $TemplatesDir "template.html"

    Convert-MarkdownToHtml `
        -MarkdownFile $MarkdownOut `
        -OutputHtml $HtmlBuildOut `
        -TemplateFile $TemplateFile `
        -LuaFilter $LuaFilter `
        -Title $CleanTitle

    # ========================================================================
    # STAGE 4: HTML NORMALIZATION
    # ========================================================================
    Write-BuildLog "STAGE 4 - HTML NORMALIZATION" -Level Debug
    if (Get-Command Normalize-Html -ErrorAction SilentlyContinue) {
        Normalize-Html -HtmlFile $HtmlBuildOut -BaseName $BaseName
        Write-BuildLog "HTML post-processing normalization complete" -Level Debug
    }

    # -------------------------------------------------------------------------
    # INJECT TOOL BUNDLE LINK (install guide only)
    # -------------------------------------------------------------------------
    if ($BaseName -eq "1-home-lab-install-procedure") {
        $GeneratedHtml = Get-Content -LiteralPath $HtmlBuildOut -Raw -Encoding UTF8
        if ($GeneratedHtml -notmatch "home-lab-tools\.zip") {
            $ToolBundleLink = @'
        <div class="download-container" style="margin-bottom: 1.5rem;">
            <details class="collapsible-download-box">
                <summary class="box-header"><span class="folder-icon">TOOLS</span> Home Lab Tools Bundle</summary>
                <div class="box-body">
                    <p>The complete build toolkit is packaged for extraction over a <code>home-lab-tools</code> directory. It includes the build script, component loader, support scripts, prompts, filters, and HTML templates.</p>
                    <a href="../assets/home-lab-tools.zip" class="download-btn" download>Download Home Lab Tools</a>
                </div>
            </details>
        </div>
'@
            $GeneratedHtml = $GeneratedHtml.Replace('<div class="title-banner"', $ToolBundleLink + "`r`n    " + '<div class="title-banner"')
            Set-Content -LiteralPath $HtmlBuildOut -Value $GeneratedHtml -Encoding UTF8
            Write-BuildLog "Injected home-lab-tools.zip link" -Level Debug
        }
    }
    # ========================================================================
    # STAGE 4.5: INSERT GOOGLE TAG MANAGER (or other head content)
    # ========================================================================
    $GTMTemplate = Join-Path $TemplatesDir "googletagmanager.txt"
    if (Test-Path -LiteralPath $GTMTemplate) {
        $GTMContent = Get-Content -LiteralPath $GTMTemplate -Raw -Encoding UTF8
        
        # Read current HTML
        $HtmlContent = Get-Content -LiteralPath $HtmlBuildOut -Raw -Encoding UTF8
        
        # Check if already inserted (prevent duplicates on re-runs)
        if ($HtmlContent -notmatch [regex]::Escape($GTMContent.Trim())) {
            # Insert after </head> and before <body>
            if ($HtmlContent -match '(?i)</head>') {
                $HtmlContent = $HtmlContent -replace '(?i)(</head>)', "$GTMContent`$1"
                Set-Content -LiteralPath $HtmlBuildOut -Value $HtmlContent -Encoding UTF8 -NoNewline
                Write-BuildLog "Inserted head content from googletagmanager.txt" -Level Debug
            }
            else {
                Write-BuildLog "WARNING: </head> tag not found in $HtmlBuildOut" -Level Warning
            }
        }
        else {
            Write-BuildLog "Head content already present (skipped duplicate insertion)" -Level Debug
        }
    }
    else {
        Write-BuildLog "googletagmanager.txt not found (skipped)" -Level Debug
    }
    
    # ========================================================================
    # STAGE 5: PREPARE DEPLOYMENT DIRECTORIES
    # ========================================================================
    Write-BuildLog "STAGE 5 - PREPARE DEPLOYMENT DIRECTORIES" -Level Debug
    $null = New-Item -ItemType Directory -Path (Split-Path $WebsiteHtml) -Force
    $null = New-Item -ItemType Directory -Path $WebsiteMedia -Force
    Write-BuildLog "Target web directories verified" -Level Debug

    # ========================================================================
    # STAGE 6: DEPLOY HTML & MEDIA ASSETS
    # ========================================================================
    Write-BuildLog "STAGE 6 - DEPLOYMENT" -Level Debug
    Copy-Item -Path $HtmlBuildOut -Destination $WebsiteHtml -Force
    Write-BuildLog "HTML deployed: $WebsiteHtml" -Level Debug

    $ExtractedMedia = Join-Path $WorkingMedia "media"
    if (Test-Path -LiteralPath $ExtractedMedia) {
        $MediaFiles = Get-ChildItem -Path $ExtractedMedia -File
        foreach ($File in $MediaFiles) {
            Copy-Item -Path $File.FullName -Destination (Join-Path $WebsiteMedia $File.Name) -Force
            Write-BuildLog "  Media: $($File.Name)" -Level Debug
        }
        Write-BuildLog "Media assets deployed: $WebsiteMedia" -Level Debug
    }

    # ========================================================================
    # STAGE 7: ARCHIVE PACKAGING (.ZIP)
    # ========================================================================
    Write-BuildLog "STAGE 7 - ARCHIVE PACKAGING" -Level Debug
    $ArchiveDir = Join-Path $ProjectRoot "assets\archives"
    $PkgDir     = Join-Path $ProjectRoot "build\working\packages\$BaseName"

    $null = New-Item -ItemType Directory -Path $ArchiveDir -Force
    $null = New-Item -ItemType Directory -Path $PkgDir -Force

    $PdfSource = Join-Path $DocBasePath "$SiteName\$TargetType\${BaseName}.pdf"
    if (Test-Path -LiteralPath $PdfSource) {
        Copy-Item -Path $PdfSource -Destination (Join-Path $PkgDir "${BaseName}.pdf") -Force
    }

    if (Test-Path -LiteralPath $ExtractedMedia) {
        Copy-Item -Path "$ExtractedMedia\*" -Destination (Join-Path $PkgDir "media") -Recurse -Force
    }

    $ZipOutputPath = Join-Path $ArchiveDir "${BaseName}.zip"
    Compress-Archive -Path "$PkgDir\*" -DestinationPath $ZipOutputPath -Force
    Write-BuildLog "Archive created: $ZipOutputPath" -Level Debug
}

Write-BuildLog "PER-DOCUMENT LOOP COMPLETE" -Level Success

# ============================================================================
# Block 10 TOOL BUNDLE & CLEANUP � Post-processing (runs once after loop)
# ============================================================================
Write-BuildLog "TOOL BUNDLE & CLEANUP" -Level Debug

$ToolBundleName = "home-lab-tools"
$ToolStageDir   = Join-Path $ProjectRoot "build\working\$ToolBundleName"
$ToolDownloadDir = Join-Path $ProjectRoot "assets\downloads"
$ToolZipPath    = Join-Path $ToolDownloadDir "$ToolBundleName.zip"
$WebsiteToolDir = Join-Path $DeployRoot "$SiteName\assets"
$WebsiteToolZip = Join-Path $WebsiteToolDir "$ToolBundleName.zip"

if (Test-Path -LiteralPath $ToolStageDir) { Remove-Item -LiteralPath $ToolStageDir -Recurse -Force }

$null = New-Item -ItemType Directory -Path $ToolStageDir -Force
$null = New-Item -ItemType Directory -Path $ToolDownloadDir -Force
$null = New-Item -ItemType Directory -Path $WebsiteToolDir -Force

Copy-Item -LiteralPath (Join-Path $ProjectRoot "build.ps1") -Destination $ToolStageDir -Force
Copy-Item -LiteralPath (Join-Path $ProjectRoot "README.md") -Destination $ToolStageDir -Force

foreach ($ToolDirName in @("config", "filters", "prompts", "scripts", "support", "templates")) {
    $ToolSrc = Join-Path $ProjectRoot $ToolDirName
    $ToolDst = Join-Path $ToolStageDir $ToolDirName
    $null = New-Item -ItemType Directory -Path $ToolDst -Force
    Copy-Item -Path (Join-Path $ToolSrc "*") -Destination $ToolDst -Recurse -Force
}

$ComponentLoader = Join-Path $DeployRoot "scripts\component-loader.js"
if (-not (Test-Path -LiteralPath $ComponentLoader)) {
    throw "Required website component loader not found: $ComponentLoader"
}
Copy-Item -LiteralPath $ComponentLoader -Destination (Join-Path $ToolStageDir "scripts\component-loader.js") -Force

if (Test-Path -LiteralPath $ToolZipPath) { Remove-Item -LiteralPath $ToolZipPath -Force }
Compress-Archive -Path (Join-Path $ToolStageDir "*") -DestinationPath $ToolZipPath -Force
Copy-Item -LiteralPath $ToolZipPath -Destination $WebsiteToolZip -Force
Write-BuildLog "Tool bundle created: $ToolZipPath" -Level Success
Write-BuildLog "Tool bundle deployed: $WebsiteToolZip" -Level Debug

# -------------------------------------------------------------------------
# Block 11 CLEANUP: Remove generated output + misplaced deployment artifacts
# -------------------------------------------------------------------------
if (Test-Path -LiteralPath (Join-Path $ProjectRoot "build\output")) {
    Get-ChildItem -LiteralPath (Join-Path $ProjectRoot "build\output") -Force | Remove-Item -Recurse -Force
}

$DeployedFiguresDir = Join-Path $DeployRoot "$SiteName\figures"
if (Test-Path -LiteralPath $DeployedFiguresDir) {
    Remove-Item -LiteralPath $DeployedFiguresDir -Recurse -Force
    Write-BuildLog "Removed obsolete deployed figures: $DeployedFiguresDir" -Level Debug
}

$WebsiteScriptsDir = Join-Path $DeployRoot "scripts"
Get-ChildItem -LiteralPath $WebsiteScriptsDir -File -Force |
    Where-Object { $_.Name -ne "component-loader.js" } |
    Remove-Item -Force
Write-BuildLog "Cleaned website scripts (kept component-loader.js)" -Level Debug

Write-BuildLog "Asset audit and cleanup completed" -Level Success
Write-BuildLog "BUILD PIPELINE COMPLETE" -Level Header
