Step 1: Create your Template File (template.html)
  open VSCode - The template file is allready created you may view it here if you wish
  Make sure you have a good msword doc - IE tables and the TOC is all updated.  The more work you do here the less you will have to do editing html.  Also you may want to view the html output and update your word doct - then rerun so that you have a master to go from

  Please make sure the file name for your docx and your html is all lowercase - use dashes if desired for readability.


Step 2: The PowerShell Command to build the Markdown file
  Open PowerShell, navigate to your folder 
     cd "C:\Users\barne\Documents\HomeAssistant\Proxmox\Published Documents\home-lab-project")
  and run these two commands.

  Command 1: Convert Word to Markdown (For you to edit in VS Code)

    PowerShell
      pandoc input.docx -f docx -t markdown --wrap=none --extract-media=./images -o output.md
  Take your time here to open output.md in VS Code, clean up your code blocks, tweak text, or organize sections.

Step 2: The PowerShell Command to build the index.html file
  Command 2: Compile Markdown + Template into the Final Web Page
  Once your Markdown is perfect, run this command to build the final HTML file:

    PowerShell
    pandoc output.md -f markdown -t html5 --template=template.html --toc --toc-depth=3 --standalone --id-prefix="nav-" -o index.html
#   pandoc output.md -f markdown -t html5 --template=template.html --toc --toc-depth=3 --standalone --id-prefix="toc-" -o index.html

      
# pandoc output.md -f markdown -t html5 --template=template.html --toc --toc-depth=3 --metadata title="My Document Title" -o index.html

  Breaking down the magic parameters:
    --template=template.html: Tells Pandoc to use the wrapper layout you made in Step 1.
    --toc: Tells Pandoc to automatically scan your Markdown headings (#, ##, ###) and generate a fully linked Table of Contents, inserting it exactly where $toc$ is in your template.
    --toc-depth=3: Controls how deep the TOC goes (H1, H2, and H3 headings).
    --metadata title="...": Dynamically replaces the $title$ tag in your HTML header.

  Pro-Tip for CSS
    Because Pandoc generates the TOC automatically as a nested list (<ul> and <li>), update your styles.css file from earlier to ensure the generated links look clean:

    CSS
    /* Style the automatically generated Pandoc TOC */
    .toc ul {
        list-style-type: none;
        padding-left: 15px;
    }
    .toc > ul {
        padding-left: 0; /* Remove padding for the outermost list */
    }
    .toc a {
        text-decoration: none;
        color: #3498db;
        display: block;
        padding: 4px 0;
    }
    .toc a:hover {
        text-decoration: underline;
    }
  Now, whenever you update your Markdown file, you just hit the up arrow in PowerShell, rerun Command 2, and your website instantly updates!

  Your Local Folder Structure (Before running the command)
  Keep everything in one project folder on your computer while you work:

Plaintext
📂 my-web-project/      (I cxalled it home-lab-project)
├── 📄 input.docx       (Your original Word file) if needed save your doc as this to remove garbage
├── 📄 output.md        (The Markdown file you edit in VS Code)
├── 📄 template.html    (The layout wrapper file)
├── 📄 styles.css       (Your stylesheet)
└── 📂 images/          (Extracted figures/images)

What Actually Goes on the Web Server

  Once Pandoc generates your index.html, you only need to upload the finished assets that the browser actually needs to display the page.

  Your production web server structure will look like this:

  Plaintext

  📂 public_html/         (or your working directory)
  ├── 📄 index.html       (The final generated page from Pandoc) rename this to your origional name during the copy
  └── 📂 images/          (Your figures and images)

  💡 Note: template.html and output.md stay safely on your hard drive. If you ever need to change the header text or update your document's content in the future, you just edit those local files, re-run the PowerShell command to generate a new index.html, and upload the updated index.html to your server.
  
  
  Final directory under web top level
📁 smart-home-edge-systems/           (Your Root Directory)
│
├── 📄 404.html
├── 📄 CNAME                          (Custom domain pointer)
├── 📄 .gitignore
├── 📄 index.html                     (Main Landing Page)
├── 📄 robots.txt
├── 📄 sitemap.xml
│
├── 📁 .github/
│   └── 📁 workflows/                 (CI/CD Automation)
│
├── 📁 assets/                        (GLOBAL Assets)
│   ├── 📁 figures/
│   │   └── 📷 [Global site banners]
│   └── 📁 icons/
│       └── 📷 main-logo.jfif         (Main site logo)
│
├── 📁 authors/
│   └── 📄 index.html
│
├── 📁 includes/
│   └── 📄 [Your moved sample header, menu, and footer .html files]
│
├── 📁 scripts/                       (GLOBAL Scripts)
│   └── 📄 component-loader.js        (Dynamic navbar/footer loader)
│
├── 📁 styles/                        (GLOBAL Styles)
│   └── 📄 global.css                 (Your master stylesheet)
│
└── 📁 home-lab/                      (Example Documentation Category)
    ├── 📄 index.html                 (Main category landing page)
    │
    ├── 📁 assets/                    (LOCAL Assets - Unique to home-lab)
    │   ├── 📁 figures/
    │   │   └── 📷 [Proxmox/Network diagrams]
    │   └── 📁 icons/
    │       └── 📷 [Hardware/LXC node icons]
    │
    ├── 📁 guides/                    (LOCAL Guides Subfolder)
    │   └── 📄 index.html             (Guides index file)
    │
    └── 📁 reference/                 (LOCAL Reference Subfolder)
        └── 📄 index.html             (Reference index file)


Part 1: How to Set the Title Inside Word (.docx)
Open your master file in Microsoft Word.

Click on the File tab in the top-left corner of the ribbon.

On the Info screen, look to the far-right column under the Properties section.

Locate the Title field (it might say Add a title if it's currently empty).

Click it and type your exact document title: Building your Smart AI capable Home Lab

Go back to your document text page, highlight and delete those top three text lines from the actual page body so they don't duplicate.

Make sure all captions are set to Heading 4 and no other items should use Heading 4 or above or they will show up in the TOC.

Save and close your file.