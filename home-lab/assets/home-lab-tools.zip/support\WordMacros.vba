Option Explicit

' ==========================================
' MAIN PUBLISH PIPELINE
' ==========================================
Sub SyncPublishAndSaveDoc()

    Dim para As Paragraph
    Dim rng As Range
    Dim subRng As Range
    Dim blockCount As Long
    Dim fld As Field
    Dim toc As TableOfContents
    Dim tof As TableOfFigures
    Dim docPath As String
    Dim pdfPath As String
    Dim pdfFolder As String
    Dim dotPos As Long
    Dim fso As Object
    
    ' Guard clause: Document must be saved so ActiveDocument.Path is valid
    If ActiveDocument.Path = "" Then
        MsgBox "Please save the Word document before running the publish pipeline.", _
               vbExclamation, "Document Not Saved"
        Exit Sub
    End If
    
    On Error GoTo ErrorHandler
    
    Application.ScreenUpdating = False
    Set fso = CreateObject("Scripting.FileSystemObject")
    
    ' ==========================================
    ' STEP 1: NORMALIZE EXTERNAL RESOURCE PATHS
    ' ==========================================
    NormalizeIncludeTextPaths fso
    NormalizeIncludePicturePaths fso

    ' ==========================================
    ' STEP 2: UPDATE ALL EXTERNAL CONTENT
    ' ==========================================
    For Each fld In ActiveDocument.Fields
        If fld.Type = wdFieldIncludeText Then
            fld.Update
            DoEvents
        End If
    Next fld
        
    ' ==========================================
    ' STEP 3: UPDATE ALL OTHER FIELDS
    ' ==========================================
    For Each fld In ActiveDocument.Fields
        If fld.Type <> wdFieldIncludeText Then
            fld.Update
            DoEvents
        End If
    Next fld
    
    ' ==========================================
    ' STEP 4: UPDATE TOC & FIGURES
    ' ==========================================
    For Each toc In ActiveDocument.TablesOfContents
        toc.Update
        DoEvents
    Next toc
    
    For Each tof In ActiveDocument.TablesOfFigures
        tof.Update
        DoEvents
    Next tof
    
    ' ==========================================
    ' STEP 5: PROCESS TEXTBLOCKS (SAFE BOUNDARY HANDLING)
    ' Convert tabs to spaces & internal paragraph marks to soft line breaks
    ' ==========================================
    blockCount = 0
    
    For Each para In ActiveDocument.Paragraphs
        If InStr(1, CStr(para.Style), "TextBlock", vbTextCompare) > 0 _
           Or InStr(1, CStr(para.Style), "Code", vbTextCompare) > 0 Then
            
            Set rng = para.Range
            
            ' Only process if paragraph contains content beyond just its trailing ¶
            If rng.Characters.count > 1 Then
                
                ' 1. Convert tabs to spaces
                Set subRng = rng.Duplicate
                subRng.End = subRng.End - 1 ' Exclude trailing paragraph mark
                
                With subRng.Find
                    .ClearFormatting
                    .Replacement.ClearFormatting
                    .Text = "^t"
                    .Replacement.Text = "  "
                    .Forward = True
                    .Wrap = wdFindStop
                    .Execute Replace:=wdReplaceAll
                End With
                
                ' 2. Safely convert internal ^p to ^l (never touching the final ¶)
                Set subRng = rng.Duplicate
                subRng.End = subRng.End - 1
                
                With subRng.Find
                    .ClearFormatting
                    .Text = "^p"
                    .Forward = True
                    .Wrap = wdFindStop
                    
                    Do While .Execute
                        ' Ensure the match is strictly BEFORE the final paragraph boundary
                        If subRng.End < rng.End Then
                            subRng.Text = Chr(11) ' Soft line break (^l)
                            blockCount = blockCount + 1
                            subRng.Collapse wdCollapseEnd
                        Else
                            Exit Do
                        End If
                    Loop
                End With
                
            End If
        End If
    Next para
    
    ' ==========================================
    ' STEP 6: UPDATE TOC & FIGURES AGAIN
    ' ==========================================
    For Each toc In ActiveDocument.TablesOfContents
        toc.Update
    Next toc
    
    For Each tof In ActiveDocument.TablesOfFigures
        tof.Update
    Next tof
    
    ' ==========================================
    ' STEP 7: SAVE DOCUMENT
    ' ==========================================
    ActiveDocument.Save
    
    ' ==========================================
    ' STEP 8: CREATE project_pdfs FOLDER
    ' ==========================================
    pdfFolder = fso.BuildPath(ActiveDocument.Path, "project_pdfs")
    
    If Not fso.FolderExists(pdfFolder) Then
        fso.CreateFolder pdfFolder
    End If
    
    ' ==========================================
    ' STEP 9: BUILD PDF PATH
    ' ==========================================
    docPath = ActiveDocument.FullName
    dotPos = InStrRev(docPath, ".")
    
    If dotPos > 0 Then
        pdfPath = fso.BuildPath(pdfFolder, Left(ActiveDocument.Name, InStrRev(ActiveDocument.Name, ".") - 1) & ".pdf")
    Else
        pdfPath = fso.BuildPath(pdfFolder, ActiveDocument.Name & ".pdf")
    End If
    
    ' ==========================================
    ' STEP 10: EXPORT PDF
    ' ==========================================
    ActiveDocument.ExportAsFixedFormat _
        OutputFileName:=pdfPath, _
        ExportFormat:=wdExportFormatPDF, _
        OpenAfterExport:=False, _
        OptimizeFor:=wdExportOptimizeForPrint, _
        Range:=wdExportAllDocument, _
        Item:=wdExportDocumentContent, _
        IncludeDocProps:=True, _
        KeepIRM:=True, _
        CreateBookmarks:=wdExportCreateNoBookmarks, _
        DocStructureTags:=True, _
        BitmapMissingFonts:=True, _
        UseISO19005_1:=False
    
CleanExit:
    Application.ScreenUpdating = True
    
    MsgBox "Pipeline Complete!" & vbCrLf & vbCrLf & _
           "- External text snippets updated" & vbCrLf & _
           "- External pictures updated" & vbCrLf & _
           "- Soft line breaks formatted: " & blockCount & vbCrLf & _
           "- TOC and Figure Tables updated" & vbCrLf & _
           "- Word document saved" & vbCrLf & _
           "- PDF created:" & vbCrLf & pdfPath, _
           vbInformation, _
           "Publish Pipeline"
    
    Exit Sub
    
ErrorHandler:
    Application.ScreenUpdating = True
    
    MsgBox "Pipeline encountered an error:" & vbCrLf & vbCrLf & _
           "Error " & Err.Number & ": " & Err.Description, _
           vbExclamation, _
           "Publish Pipeline"

End Sub


' ==========================================
' NORMALIZE INCLUDETEXT PATHS
' ==========================================
Private Sub NormalizeIncludeTextPaths(ByVal fso As Object)

    Dim fld As Field
    Dim codeText As String
    Dim sourcePath As String
    Dim fileName As String
    Dim q1 As Long, q2 As Long
    Dim candidateFolders As Variant
    Dim i As Long
    Dim testPath As String
    Dim foundPath As String
    Dim escapedPath As String
    
    candidateFolders = Array("", "project_snipets", "project_snippets", "project_scripts")
    
    For Each fld In ActiveDocument.Fields
        If fld.Type = wdFieldIncludeText Then
            codeText = fld.Code.Text
            
            q1 = InStr(1, codeText, """")
            If q1 = 0 Then GoTo NextField
            
            q2 = InStr(q1 + 1, codeText, """")
            If q2 = 0 Then GoTo NextField
            
            sourcePath = Mid$(codeText, q1 + 1, q2 - q1 - 1)
            sourcePath = Replace(sourcePath, "\\", "\")
            sourcePath = Replace(sourcePath, "/", "\")
            
            If InStr(sourcePath, "\") > 0 Then
                fileName = Mid$(sourcePath, InStrRev(sourcePath, "\") + 1)
            Else
                fileName = sourcePath
            End If
            
            If Trim$(fileName) = "" Then GoTo NextField
            
            foundPath = ""
            
            ' 1. Check existing path relative to document folder
            testPath = fso.BuildPath(ActiveDocument.Path, sourcePath)
            If fso.FileExists(testPath) Then
                foundPath = testPath
            Else
                ' 2. Search candidate subfolders
                For i = LBound(candidateFolders) To UBound(candidateFolders)
                    If candidateFolders(i) = "" Then
                        testPath = fso.BuildPath(ActiveDocument.Path, fileName)
                    Else
                        testPath = fso.BuildPath(fso.BuildPath(ActiveDocument.Path, candidateFolders(i)), fileName)
                    End If
                    
                    If fso.FileExists(testPath) Then
                        foundPath = testPath
                        Exit For
                    End If
                Next i
            End If
            
            If foundPath <> "" Then
                escapedPath = Replace(foundPath, "\", "\\")
                fld.Code.Text = " INCLUDETEXT """ & escapedPath & """ \* MERGEFORMAT "
            Else
                MsgBox "Snippet/Script file was not found:" & vbCrLf & fileName & vbCrLf & vbCrLf & _
                       "Searched in project directory subfolders.", _
                       vbExclamation, "INCLUDETEXT Source Missing"
            End If
        End If
NextField:
    Next fld

End Sub


' ==========================================
' NORMALIZE INCLUDEPICTURE PATHS
' ==========================================
Private Sub NormalizeIncludePicturePaths(ByVal fso As Object)

    Dim fld As Field
    Dim codeText As String
    Dim fileName As String
    Dim sourcePath As String
    Dim q1 As Long, q2 As Long
    Dim candidateFolders As Variant
    Dim i As Long
    Dim testPath As String
    Dim foundPath As String
    Dim escapedPath As String
    
    candidateFolders = Array("", "project_images", "images", "pictures")
    
    For Each fld In ActiveDocument.Fields
        If fld.Type = wdFieldIncludePicture Then
            codeText = fld.Code.Text
            
            q1 = InStr(1, codeText, """")
            If q1 > 0 Then
                q2 = InStr(q1 + 1, codeText, """")
                If q2 > q1 Then
                    sourcePath = Mid$(codeText, q1 + 1, q2 - q1 - 1)
                    sourcePath = Replace(sourcePath, "\\", "\")
                    sourcePath = Replace(sourcePath, "/", "\")
                    
                    If InStr(sourcePath, "\") > 0 Then
                        fileName = Mid$(sourcePath, InStrRev(sourcePath, "\") + 1)
                    Else
                        fileName = sourcePath
                    End If
                    
                    If Trim$(fileName) = "" Then GoTo NextField
                    
                    foundPath = ""
                    
                    testPath = fso.BuildPath(ActiveDocument.Path, sourcePath)
                    If fso.FileExists(testPath) Then
                        foundPath = testPath
                    Else
                        For i = LBound(candidateFolders) To UBound(candidateFolders)
                            If candidateFolders(i) = "" Then
                                testPath = fso.BuildPath(ActiveDocument.Path, fileName)
                            Else
                                testPath = fso.BuildPath(fso.BuildPath(ActiveDocument.Path, candidateFolders(i)), fileName)
                            End If
                            
                            If fso.FileExists(testPath) Then
                                foundPath = testPath
                                Exit For
                            End If
                        Next i
                    End If
                    
                    If foundPath <> "" Then
                        escapedPath = Replace(foundPath, "\", "\\")
                        fld.Code.Text = " INCLUDEPICTURE """ & escapedPath & """ \d "
                    End If
                End If
            End If
        End If
NextField:
    Next fld

End Sub

