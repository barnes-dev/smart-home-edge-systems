# ============================================================================
# CREATE RELEASE 1.1 BASELINE ARCHIVE
# ============================================================================
#
# Location: support/Create-ReleaseBaseline-1.1.ps1
# Purpose:  Creates a Release-1.1-Baseline.zip archive containing the
#           current working state and stores it in the 'baselines/' directory.
#
# Usage:    .\support\Create-ReleaseBaseline-1.1.ps1
#
# ============================================================================

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$Version = "1.1",

    [Parameter(Mandatory = $false)]
    [string]$BaselinesFolder = "baselines"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

Write-Host ""
Write-Host "======================================================================" -ForegroundColor DarkGray
Write-Host " CREATE RELEASE $Version BASELINE" -ForegroundColor White -BackgroundColor DarkBlue
Write-Host "======================================================================" -ForegroundColor DarkGray
Write-Host ""

# ============================================================================
# CONFIGURATION & PATH RESOLUTION
# ============================================================================

# Detects project root whether called from root or inside support/
if ((Split-Path -Leaf $PSScriptRoot) -eq "support") {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
} else {
    $ProjectRoot = $PSScriptRoot
}

$BaselineName = "Release-$Version-Baseline"
$BaselinesDirPath = Join-Path $ProjectRoot $BaselinesFolder
$ZipPath = Join-Path $BaselinesDirPath "$BaselineName.zip"

# Core source items to include in baseline
$IncludeFiles = @(
    "build.ps1",
    "README.md",
    "CHANGELOG.md"
)

$IncludeDirectories = @(
    "scripts",
    "templates", 
    "filters",
    "prompts",
    "support"
)

# ============================================================================
# PREPARATION
# ============================================================================

Write-Host "--> Preparing baseline target path..." -ForegroundColor Cyan

# Ensure target 'baselines' directory exists in project root
if (-not (Test-Path $BaselinesDirPath)) {
    New-Item -Path $BaselinesDirPath -ItemType Directory -Force | Out-Null
    Write-Host "    [CREATE] Directory: $BaselinesDirPath" -ForegroundColor Green
}

# Setup temp staging directory
$TempDir = Join-Path $env:TEMP "Baseline_$([Guid]::NewGuid())"
New-Item -Path $TempDir -ItemType Directory -Force | Out-Null

$StagingDir = Join-Path $TempDir $BaselineName
New-Item -Path $StagingDir -ItemType Directory -Force | Out-Null

Write-Host "    [STAGING] Temp workspace: $TempDir" -ForegroundColor DarkCyan

# ============================================================================
# COPY FILES
# ============================================================================

Write-Host ""
Write-Host "--> Copying source files to staging..." -ForegroundColor Cyan

foreach ($file in $IncludeFiles) {
    $sourcePath = Join-Path $ProjectRoot $file
    if (Test-Path $sourcePath) {
        $destPath = Join-Path $StagingDir $file
        Copy-Item -Path $sourcePath -Destination $destPath -Force
        Write-Host "    [COPY] $file" -ForegroundColor Green
    } else {
        Write-Host "    [SKIP] $file (not found)" -ForegroundColor Yellow
    }
}

foreach ($dir in $IncludeDirectories) {
    $sourcePath = Join-Path $ProjectRoot $dir
    if (Test-Path $sourcePath) {
        $destPath = Join-Path $StagingDir $dir
        Copy-Item -Path $sourcePath -Destination $destPath -Recurse -Force
        Write-Host "    [COPY] $dir\" -ForegroundColor Green
    } else {
        Write-Host "    [SKIP] $dir\ (not found)" -ForegroundColor Yellow
    }
}

# ============================================================================
# CREATE ZIP ARCHIVE
# ============================================================================

Write-Host ""
Write-Host "--> Creating ZIP archive in baselines folder..." -ForegroundColor Cyan

try {
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    Write-Host "    [ZIP] Created: $ZipPath" -ForegroundColor Green
} catch {
    Write-Error "Failed to create ZIP archive: $_"
    exit 1
}

# ============================================================================
# CLEANUP
# ============================================================================

Write-Host ""
Write-Host "--> Cleaning temporary files..." -ForegroundColor Cyan

try {
    Remove-Item -Path $TempDir -Recurse -Force
    Write-Host "    [CLEAN] Removed temporary staging directory" -ForegroundColor Green
} catch {
    Write-Warning "Failed to remove temporary directory: $TempDir"
}

# ============================================================================
# VERIFICATION & SUMMARY
# ============================================================================

Write-Host ""
Write-Host "--> Verifying baseline archive..." -ForegroundColor Cyan

if (Test-Path $ZipPath) {
    $zipSizeMB = [math]::Round(((Get-Item $ZipPath).Length / 1MB), 2)
    
    Write-Host ""
    Write-Host "======================================================================" -ForegroundColor Green
    Write-Host " RELEASE $Version BASELINE CREATION COMPLETE " -ForegroundColor White -BackgroundColor DarkGreen
    Write-Host "======================================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Archive Location: $ZipPath" -ForegroundColor Cyan
    Write-Host "Archive Size:     $zipSizeMB MB" -ForegroundColor DarkCyan
    Write-Host ""
} else {
    Write-Error "Archive verification failed."
    exit 1
}