function Header(el)
  if el.level == 5 then
    local heading_text = pandoc.utils.stringify(el.content)
    local zip_name = heading_text:lower():gsub("%s+", "-"):gsub("[^a-z0-9%-]", "")
    
    -- Paths matching your tracking structure
    local folder_url = "../assets/figures/" .. zip_name
    local download_url = folder_url .. "/" .. zip_name .. ".zip"
    
    -- We build a container that has both a download button AND an internal view block
    local html_wrapper = string.format([[
      <div class="download-container">
          <details class="collapsible-download-box">
              <summary class="box-header">
                  <span class="folder-icon">📂</span> %s
              </summary>
              <div class="box-body">
                  <p>This automated bundle contains the baseline configurations, code layouts, and operational manifests tracked for this module.</p>
                  
                  <!-- Internal Preview Block Context -->
                  <div class="asset-preview-pane">
                      <h4 class="preview-title">👁️ Internal Asset Preview</h4>
                      <div class="preview-gallery">
                          <!-- Your webpage will display images or file links here -->
                          <p class="preview-instructions">All embedded diagrams, schematics, and configurations are packaged below. Click the button to download the full-resolution archive block.</p>
                      </div>
                  </div>

                  <a href="%s" class="download-btn" download>Download Asset Archive Bundle</a>
              </div>
          </details>
      </div>
    ]], heading_text, download_url)
    
    return pandoc.RawBlock('html', html_wrapper)
  end
end
-- (Your existing code for collapsible downloads goes here...)

-----------------------------------------------------------------
-- Custom Style Mapper (Passes Word custom-styles into HTML classes)
-----------------------------------------------------------------
function Div(el)
    local style = el.attributes['custom-style']
    if style then
        table.insert(el.classes, 'custom-style-' .. style)
        table.insert(el.classes, style)
    end
    return el
end

function Span(el)
    local style = el.attributes['custom-style']
    if style then
        table.insert(el.classes, 'custom-style-' .. style)
        table.insert(el.classes, style)
    end
    return el
end