﻿# ============================================================================
# ASSET FUNCTIONS
# ============================================================================
#
# Maintained for Smart-Home-Edge-Systems.us by ChatGPT.
#
# Purpose:
#   Handles extracted images, asset naming, HTML references, and ZIP files.
#
# ============================================================================

function Get-ExtractedMediaDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$AssetDirectory
    )

    return (Join-Path $AssetDirectory "media")
}

function Get-ExtractedMediaFiles {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MediaDirectory
    )

    if (-not (Test-Path -LiteralPath $MediaDirectory)) {
        return @()
    }

    return @(Get-ChildItem `
        -Path $MediaDirectory `
        -File `
        | Sort-Object Name)
}

function New-AssetArchive {
    param(
        [Parameter(Mandatory = $true)]
        [string]$AssetDirectory,

        [Parameter(Mandatory = $true)]
        [string]$ArchivePath
    )

    $Files = Get-ChildItem `
        -Path $AssetDirectory `
        -File `
        | Where-Object { $_.FullName -ne $ArchivePath }

    if (-not $Files) {
        return $false
    }

    if (Test-Path -LiteralPath $ArchivePath) {
        Remove-Item -LiteralPath $ArchivePath -Force
    }

    Compress-Archive `
        -Path $Files.FullName `
        -DestinationPath $ArchivePath `
        -Force

    return (Test-Path -LiteralPath $ArchivePath)
}

function Remove-TemporaryMediaDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MediaDirectory
    )

    if (Test-Path -LiteralPath $MediaDirectory) {
        Remove-Item `
            -LiteralPath $MediaDirectory `
            -Recurse `
            -Force
    }
}

function Normalize-MarkdownMedia {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MarkdownFile,

        [Parameter(Mandatory = $true)]
        [string]$BaseName
    )

    if (-not (Test-Path -LiteralPath $MarkdownFile)) {
        Write-BuildLog "Normalize-MarkdownMedia: Markdown file not found at '$MarkdownFile'." -Level Warning
        return
    }

    Write-BuildLog "Normalizing media links and TextBlocks in Markdown file: $MarkdownFile" -Level Debug
    
    # Safely read file text, handling BOM variations automatically
    $sr = [System.IO.StreamReader]::new($MarkdownFile, $true)
    $content = $sr.ReadToEnd()
    $sr.Close()

    # 1. Update image paths to target '../figures/'
    $updatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $content,
        '(!\[.*?\]\()(.+?[\\/])?([^\\/]+\.(png|jpg|jpeg|gif))(\))',
        '$1../figures/$3$5',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    # 2. Wrap standalone image lines in a markdown table structure
    $updatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $updatedContent,
        '(?m)^(!\[.*?\]\(.+?\))$',
        "|`n|---|`n| `$1 |`n|---|",
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    # 3. Wrap custom TextBlocks inside proper markdown table structures (matching Code styles)
    # This catches blocks starting with `::: {custom-style="TextBlock"}` and wraps them into a table
    $updatedContent = [System.Text.RegularExpressions.Regex]::Replace(
        $updatedContent,
        '(\:\:\:\s*\{custom-style=["“]TextBlock["”]\}\s*\r?\n)([\s\S]*?)(\r?\n\s*\:\:\:)',
        '|`n|---|`n| $2 |`n|---|',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    if ($content -ne $updatedContent) {
        # Write back cleanly using standard UTF-8 without forcing a stray BOM header
        [System.IO.File]::WriteAllText($MarkdownFile, $updatedContent, [System.Text.UTF8Encoding]::new($false))
        Write-BuildLog "Successfully normalized image paths and wrapped TextBlocks in tables." -Level Debug
    } else {
        Write-BuildLog "No matching elements found to normalize." -Level Debug
    }
}