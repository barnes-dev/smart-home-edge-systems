# ============================================================================
# CREATE RELEASE BASELINE
# ============================================================================
#
# Purpose: Creates a Release-1.1-Baseline.zip archive containing the
# current working state of the documentation build pipeline.
#
# Usage: .\Create-ReleaseBaseline.ps1
#
# ============================================================================

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "Release-1.1-Baseline.zip"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

Write-Host ""
Write-Host "======================================================================" -ForegroundColor DarkGray
Write-Host " CREATE RELEASE 1.1 BASELINE" -ForegroundColor White -BackgroundColor DarkBlue
Write-Host "======================================================================" -ForegroundColor DarkGray
Write-Host ""

# ============================================================================
# CONFIGURATION
# ============================================================================

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$BaselineName = "Release-1.1-Baseline"
$ZipPath = Join-Path $ProjectRoot $OutputPath

# Files and directories to include in baseline
$IncludeFiles = @(
    "build.ps1",
    "README.md",
    "CHANGELOG.md"
)

$IncludeDirectories = @(
    "scripts",
    "templates", 
    "filters",
    "prompts",
    "support"
)

# Files and directories to exclude
$ExcludePatterns = @(
    "*.log",
    "*.tmp",
    "*~",
    ".git",
    ".gitignore",
    "build",
    "smart-home-edge-systems",
    "baselines"
)

# ============================================================================
# VALIDATION
# ============================================================================

Write-Host "--> Validating project structure..." -ForegroundColor Cyan

if (-not (Test-Path $ProjectRoot)) {
    Write-Error "Project root not found: $ProjectRoot"
    exit 1
}

# ============================================================================
# PREPARATION
# ============================================================================

Write-Host "--> Preparing baseline archive..." -ForegroundColor Cyan

# Create temporary directory for baseline
$TempDir = Join-Path $env:TEMP "Baseline_$([Guid]::NewGuid())"
New-Item -Path $TempDir -ItemType Directory -Force | Out-Null

# Create baseline directory structure
$BaselineDir = Join-Path $TempDir $BaselineName
New-Item -Path $BaselineDir -ItemType Directory -Force | Out-Null

Write-Host "--> Temporary directory: $TempDir" -ForegroundColor DarkCyan

# ============================================================================
# COPY FILES
# ============================================================================

Write-Host ""
Write-Host "--> Copying baseline files..." -ForegroundColor Cyan

# Copy individual files
foreach ($file in $IncludeFiles) {
    $sourcePath = Join-Path $ProjectRoot $file
    if (Test-Path $sourcePath) {
        $destPath = Join-Path $BaselineDir $file
        Copy-Item -Path $sourcePath -Destination $destPath -Force
        Write-Host "    [COPY] $file" -ForegroundColor Green
    } else {
        Write-Host "    [SKIP] $file (not found)" -ForegroundColor Yellow
    }
}

# Copy directories
foreach ($dir in $IncludeDirectories) {
    $sourcePath = Join-Path $ProjectRoot $dir
    if (Test-Path $sourcePath) {
        $destPath = Join-Path $BaselineDir $dir
        Copy-Item -Path $sourcePath -Destination $destPath -Recurse -Force
        Write-Host "    [COPY] $dir\" -ForegroundColor Green
    } else {
        Write-Host "    [SKIP] $dir\ (not found)" -ForegroundColor Yellow
    }
}

# ============================================================================
# CREATE ZIP ARCHIVE
# ============================================================================

Write-Host ""
Write-Host "--> Creating ZIP archive..." -ForegroundColor Cyan

try {
    Compress-Archive -Path "$BaselineDir\*" -DestinationPath $ZipPath -Force
    Write-Host "    [ZIP] Created: $ZipPath" -ForegroundColor Green
} catch {
    Write-Error "Failed to create ZIP archive: $_"
    exit 1
}

# ============================================================================
# CLEANUP
# ============================================================================

Write-Host ""
Write-Host "--> Cleaning temporary files..." -ForegroundColor Cyan

try {
    Remove-Item -Path $TempDir -Recurse -Force
    Write-Host "    [CLEAN] Removed temporary directory" -ForegroundColor Green
} catch {
    Write-Warning "Failed to remove temporary directory: $TempDir"
}

# ============================================================================
# VERIFICATION
# ============================================================================

Write-Host ""
Write-Host "--> Verifying baseline archive..." -ForegroundColor Cyan

if (Test-Path $ZipPath) {
    $zipSize = (Get-Item $ZipPath).Length
    $zipSizeMB = [math]::Round($zipSize / 1MB, 2)
    
    Write-Host "    [OK] Archive created successfully" -ForegroundColor Green
    Write-Host "    [INFO] Size: $zipSizeMB MB" -ForegroundColor DarkCyan
    Write-Host "    [INFO] Location: $ZipPath" -ForegroundColor DarkCyan
} else {
    Write-Error "Archive verification failed"
    exit 1
}

# ============================================================================
# SUMMARY
# ============================================================================

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Green
Write-Host " RELEASE 1.1 BASELINE CREATION COMPLETE " -ForegroundColor White -BackgroundColor DarkGreen
Write-Host "======================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Baseline archive: $ZipPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "This baseline contains the Release 1.1 working state:" -ForegroundColor White
Write-Host "  - Core build pipeline (build.ps1)" -ForegroundColor DarkCyan
Write-Host "  - Documentation (README.md, CHANGELOG.md)" -ForegroundColor DarkCyan
Write-Host "  - PowerShell scripts (scripts/)" -ForegroundColor DarkCyan
Write-Host "  - Templates and filters (templates/, filters/)" -ForegroundColor DarkCyan
Write-Host "  - Supporting files (support/)" -ForegroundColor DarkCyan
Write-Host ""
Write-Host "Ready for Git commit and deployment." -ForegroundColor Green
Write-Host ""

