Get-Content .\build.ps1 | 
Select-String -Pattern '^#\s*BLOCK\s+\d{2}\s*[—–-]\s*.+$' | 
ForEach-Object { 
    $_ -match 'BLOCK\s+(\d{2})\s*[—–-]\s*(.+)$' | Out-Null
    [pscustomobject]@{Line=$_.LineNumber; Block=$matches[1]; Name=$matches[2].Trim()}
} | Format-Table -AutoSize Line, Block, Name