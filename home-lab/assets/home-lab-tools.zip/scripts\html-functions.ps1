﻿# ============================================================================
# HTML FUNCTIONS
# ============================================================================
#
# Home Lab Documentation Build Pipeline
# Maintained for Smart-Home-Edge-Systems.us
#
# Purpose:
#    HTML cleanup and normalization functions.
#
# ============================================================================

function Normalize-HtmlLabels {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Html
    )

    # Figure labels
    $FigureIndex = 0
    $Html = [regex]::Replace($Html, '\bFigure(?:\s*|&nbsp;)*\d*:', {
        param($match)
        $script:FigureIndex++
        "Figure ${script:FigureIndex}:"
    })

    # Table labels
    $TableIndex = 0
    $Html = [regex]::Replace($Html, '\bTable(?:\s*|&nbsp;)*\d*:', {
        param($match)
        $script:TableIndex++
        "Table ${script:TableIndex}:"
    })

    # Code labels
    $CodeIndex = 0
    $Html = [regex]::Replace($Html, '\bCode(?:\s*|&nbsp;)*\d*:', {
        param($match)
        $script:CodeIndex++
        "Code ${script:CodeIndex}:"
    })

    return $Html
}

function Save-NormalizedHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$InputPath,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath
    )

    if (-not (Test-Path -LiteralPath $InputPath)) {
        throw "HTML input file not found: $InputPath"
    }

    $Html = Get-Content `
        -LiteralPath $InputPath `
        -Raw `
        -ErrorAction Stop

    $Html = Normalize-HtmlLabels -Html $Html

    $OutputDirectory = Split-Path `
        -Parent `
        $OutputPath

    if (-not (Test-Path -LiteralPath $OutputDirectory)) {
        New-Item `
            -ItemType Directory `
            -Path $OutputDirectory `
            -Force |
            Out-Null
    }

    Set-Content `
        -LiteralPath $OutputPath `
        -Value $Html `
        -Encoding UTF8 `
        -ErrorAction Stop
}

# ============================================================================
# PIPELINE ENTRYPOINTS
# ============================================================================

function Normalize-Html {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$HtmlFile,

        [Parameter(Mandatory = $false)]
        [string]$BaseName = ""
    )

    if (-not (Test-Path -LiteralPath $HtmlFile)) {
        throw "HTML file not found: $HtmlFile"
    }

    $Content = Get-Content -LiteralPath $HtmlFile -Raw -Encoding UTF8

    # 1. Repoint image / figure paths if BaseName is provided
    if (-not [string]::IsNullOrWhiteSpace($BaseName)) {
        # Rewrites img src paths containing 'figures/' or '../figures/' to point to '$BaseName/media/'
        $Content = [regex]::Replace(
            $Content,
            'src="[^"]*?[\\/]figures[\\/]([^"]+)"',
            'src="' + "$BaseName/media/" + '$1"'
        )
    }

    # Figure labels are assigned during DOCX -> Markdown normalization.
    # Do not renumber the HTML alt text and figcaption as separate figures.

    Set-Content -LiteralPath $HtmlFile -Value $Content -Encoding UTF8
    Write-BuildLog "Normalized HTML: $HtmlFile" -Level Debug
}
