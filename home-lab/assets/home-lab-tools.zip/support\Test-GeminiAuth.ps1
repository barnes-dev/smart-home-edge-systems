<#
.SYNOPSIS
    Standalone test script to verify Gemini CLI installation and API authentication.
.LOCATION
    support\Test-GeminiAuth.ps1
#>

[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "         GEMINI CLI AUTHENTICATION TEST              " -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan

# 1. Check CLI Installation
Write-Host "`n[1/3] Checking Gemini CLI Installation..." -NoNewline
$geminiCmd = Get-Command "gemini" -ErrorAction SilentlyContinue

if (-not $geminiCmd) {
    Write-Host " [FAILED]" -ForegroundColor Red
    Write-Error "Gemini CLI ('gemini') was not found in your system PATH."
    exit 1
}
Write-Host " [OK]" -ForegroundColor Green
Write-Host "      Path: $($geminiCmd.Source)" -ForegroundColor Gray

# 2. Check Prompt Template File
Write-Host "`n[2/3] Checking Prompt Template File..." -NoNewline
$PromptPath = Join-Path $PSScriptRoot "..\prompts\technical-review.md"
if (Test-Path -LiteralPath $PromptPath) {
    Write-Host " [OK]" -ForegroundColor Green
    Write-Host "      Found: $PromptPath" -ForegroundColor Gray
} else {
    Write-Host " [FAILED]" -ForegroundColor Red
    Write-Error "Missing prompt template at: $PromptPath"
    exit 1
}

# 3. Test API Auth and Live Generation
Write-Host "`n[3/3] Testing Gemini API Authorization & Connectivity..."

# Temporarily set ErrorActionPreference to Continue to prevent stderr warnings from triggering script failure
$origPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"

try {
    $rawResult = & gemini --approval-mode plan --prompt "Say READY" 2>&1 | Out-String
}
finally {
    $ErrorActionPreference = $origPreference
}

if ($LASTEXITCODE -eq 0 -and $rawResult -match "READY") {
    Write-Host "      API Call Succeeded!" -ForegroundColor Green
    Write-Host "      Response: READY" -ForegroundColor Gray
    Write-Host "`n====================================================" -ForegroundColor Cyan
    Write-Host " SUCCESS: Gemini CLI is authenticated and operational." -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Cyan
} else {
    Write-Host "      API Call Failed!" -ForegroundColor Red
    Write-Host "      Output received:`n$rawResult" -ForegroundColor Gray
    exit 1
}