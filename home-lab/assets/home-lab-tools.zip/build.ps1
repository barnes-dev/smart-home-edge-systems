[CmdletBinding()]
param(
    [Parameter(Mandatory = $false, Position = 0)]
    [string]$Document = "home-lab\guides\1-home-lab-install-procedure.docx",

    [Parameter(Mandatory = $false, Position = 1)]
    [string]$DocBaseName = $null,

    [Parameter(Mandatory = $false, Position = 2)]
    [ValidateSet("guides", "reference")]
    [string]$TargetFolder = $null,

    [Parameter(Mandatory = $false)]
    [string]$SiteName = "home-lab",

    [Parameter(Mandatory = $false)]
    [switch]$RunModel,

    [Parameter(Mandatory = $false)]
    [switch]$UseAIReview,

    [Parameter(Mandatory = $false)]
    [switch]$DebugMode
)

# ----------------------------------------------------------------------------
# Helper Functions
# ----------------------------------------------------------------------------
function Split-DocumentPath {
    param([string]$Path)
    $parts = $Path -split '[\\/]'
    if ($parts.Count -lt 3) { throw "Path must be SiteName\TargetFolder\FileName.ext" }
    return @{
        SiteName     = $parts[0]
        TargetFolder = $parts[1]
        DocBaseName  = [IO.Path]::GetFileNameWithoutExtension($parts[2])
        Extension    = [IO.Path]::GetExtension($parts[2]).TrimStart('.')
        FileName     = $parts[2]
    }
}

# ============================================================================
# BLOCK 01 — BUILD IDENTITY & INITIALIZATION
# ============================================================================

# Load common logging utilities via relative script root
. (Join-Path $PSScriptRoot "scripts\common.ps1")

# Initialize logger explicitly converting switch to boolean
Set-BuildLogFile -Path (Join-Path $PSScriptRoot "build\logs\build.log") -EnableDebug ($DebugMode.IsPresent) -ClearLog

$BuildVersion = "1.1"

Write-BuildLog "HOME LAB DOCUMENTATION BUILD PIPELINE" -Level Header
Write-BuildLog "Maintained for Smart-Home-Edge-Systems.us" -Level Debug
Write-BuildLog "Release: $BuildVersion" -Level Debug

# ============================================================================
# BLOCK 02 — PROJECT ROOT & PATH RESOLUTION
# ============================================================================
# Derive execution anchor dynamically
$ProjectRoot = $PSScriptRoot

Write-BuildLog "BLOCK 02 - PROJECT ROOT & PATH RESOLUTION" -Level Debug

# Process input document path and extract metadata
$doc = Split-DocumentPath -Path $Document
$SiteName   = $doc.SiteName
$TargetType = $doc.TargetFolder
$BaseName   = $doc.DocBaseName
$Extension  = $doc.Extension

# Debug logs (Console only with -DebugMode, file always)
Write-BuildLog "Assigned Variables (Block 02):" -Level Debug
Write-BuildLog "  `$ProjectRoot : $ProjectRoot" -Level Debug
Write-BuildLog "  `$SiteName    : $SiteName" -Level Debug
Write-BuildLog "  `$TargetType  : $TargetType" -Level Debug
Write-BuildLog "  `$BaseName    : $BaseName" -Level Debug
Write-BuildLog "  `$Extension   : $Extension" -Level Debug

# ============================================================================
# BLOCK 03 — PROJECT PATHS (INDIRECT / RELATIVE RESOLUTION)
# ============================================================================
Write-BuildLog "BLOCK 03 - PROJECT PATHS" -Level Debug

# Internal workspace paths (relative to script location)
$ConfigDir    = Join-Path $ProjectRoot "config"
$ScriptsDir   = Join-Path $ProjectRoot "scripts"
$PromptsDir   = Join-Path $ProjectRoot "prompts"
$TemplatesDir = Join-Path $ProjectRoot "templates"
$FiltersDir   = Join-Path $ProjectRoot "filters"
$AssetsDir    = Join-Path $ProjectRoot "assets"
$FiguresDir   = Join-Path $AssetsDir "figures"

# Relative external source repository path (../site-documentation)
$DocBasePath  = [IO.Path]::GetFullPath((Join-Path $ProjectRoot "..\site-documentation"))
$GuidesDir    = Join-Path $DocBasePath "$SiteName\guides"
$ReferenceDir = Join-Path $DocBasePath "$SiteName\reference"

# Relative local build artifacts
$MarkdownOut  = Join-Path $ProjectRoot "build\output\${BaseName}.md"
$WorkingMedia = Join-Path $ProjectRoot "build\working\$BaseName"
$HtmlBuildOut = Join-Path $ProjectRoot "build\output\${BaseName}.html"

# Relative deployment target repository path (../smart-home-edge-systems)
$DeployRoot    = [IO.Path]::GetFullPath((Join-Path $ProjectRoot "..\smart-home-edge-systems"))
$WebsiteHtml   = Join-Path $DeployRoot "$SiteName\$TargetType\${BaseName}.html"
$WebsiteMedia  = Join-Path $DeployRoot "$SiteName\$TargetType\$BaseName\media"
$WebsiteAssets = Join-Path $DeployRoot "$SiteName\$TargetType\$BaseName\assets"

Write-BuildLog "Input Data:" -Level Debug
Write-BuildLog "  Processing document: $Document" -Level Debug
Write-BuildLog "  Site Name: $SiteName" -Level Debug
Write-BuildLog "  Source category: $TargetFolder" -Level Debug

# ============================================================================
# BLOCK 04 — PROJECT STRUCTURE VALIDATION
# ============================================================================
Write-BuildLog "BLOCK 04 - PROJECT STRUCTURE VALIDATION" -Level Debug

$RequiredDirectories = @(
    $ConfigDir
    $ScriptsDir
    $PromptsDir
    $TemplatesDir
    $FiltersDir
    $GuidesDir
    $ReferenceDir
    $AssetsDir
    $FiguresDir
)

foreach ($RequiredDirectory in $RequiredDirectories) {
    if (-not (Test-Path -LiteralPath $RequiredDirectory)) {
        Write-BuildLog "Missing directory detected: $RequiredDirectory" -Level Warning
        try {
            New-Item -ItemType Directory -Path $RequiredDirectory -Force -ErrorAction Stop | Out-Null
            Write-BuildLog "  Created missing directory." -Level Debug
        }
        catch {
            Write-BuildLog "CRITICAL: Could not verify required project directory.`nDirectory: $RequiredDirectory`nError: $_" -Level Error
            return
        }
    }
}

$StructureValid = $true
foreach ($RequiredDirectory in $RequiredDirectories) {
    if (Test-Path -LiteralPath $RequiredDirectory) {
        Write-BuildLog "Verified directory: $RequiredDirectory" -Level Debug
    }
    else {
        Write-BuildLog "Missing directory: $RequiredDirectory" -Level Error
        $StructureValid = $false
    }
}

if (-not $StructureValid) {
    Write-BuildLog "CRITICAL: Home Lab project structure validation failed.`nProject root: $ProjectRoot" -Level Error
    return
}

Write-BuildLog "Project structure validation completed successfully." -Level Success

# Debug logs (Console only with -DebugMode, file always)
Write-BuildLog "Working Data:" -Level Debug
Write-BuildLog "  Markdown output: $MarkdownOut" -Level Debug
Write-BuildLog "  Working asset directory: $WorkingMedia" -Level Debug
Write-BuildLog "  HTML build output: $HtmlBuildOut" -Level Debug

Write-BuildLog "Publishing Data:" -Level Debug
Write-BuildLog "  Website HTML: $WebsiteHtml" -Level Debug
Write-BuildLog "  Website media: $WebsiteMedia" -Level Debug

# ============================================================================
# BLOCK 05 — LOAD SCRIPT LIBRARIES
# ============================================================================
Write-BuildLog "BLOCK 05 - LOAD SCRIPT LIBRARIES" -Level Debug

# Define required script module filenames
$RequiredScripts = @(
    "common.ps1"
    "document-discovery.ps1"
    "pandoc-functions.ps1"
    "html-functions.ps1"
    "asset-functions.ps1"
)

# Pre-flight Validation
$MissingScripts = @()
foreach ($ScriptName in $RequiredScripts) {
    $ScriptPath = Join-Path $ScriptsDir $ScriptName
    if (-not (Test-Path -LiteralPath $ScriptPath -PathType Leaf)) {
        $MissingScripts += $ScriptPath
    }
}

if ($MissingScripts.Count -gt 0) {
    Write-BuildLog "CRITICAL: Required script library/libraries are missing:" -Level Error
    foreach ($MissingScript in $MissingScripts) {
        Write-BuildLog "  Missing: $MissingScript" -Level Error
    }
    Write-BuildLog "The modular pipeline cannot continue. Check the scripts\ directory." -Level Error
    return
}

Write-BuildLog "All required script libraries verified in: $ScriptsDir" -Level Debug

# Load remaining modular libraries
$ModulesToLoad = @(
    "document-discovery.ps1"
    "pandoc-functions.ps1"
    "html-functions.ps1"
    "asset-functions.ps1"
)

foreach ($ModuleName in $ModulesToLoad) {
    $ModulePath = Join-Path $ScriptsDir $ModuleName
    try {
        . $ModulePath
        Write-BuildLog "Loaded library: $ModuleName" -Level Debug
    }
    catch {
        Write-BuildLog "CRITICAL: Failed to load script library: $ModuleName`nError: $_" -Level Error
        return
    }
}

Write-BuildLog "Script library loading completed successfully." -Level Success

# ============================================================================
# BLOCK 11 — MODEL CONFIGURATION
# ============================================================================
Write-BuildLog "BLOCK 11 - MODEL CONFIGURATION" -Level Debug

$ModelProvider = "none"
$ModelName     = "none"

if ($RunModel) {
    Write-BuildLog "Model processing requested." -Level Debug
    Write-BuildLog "Current Provider: $ModelProvider" -Level Debug
    Write-BuildLog "Model Target:    $ModelName" -Level Debug
    Write-BuildLog "Model execution is disabled in this build version. Proceeding with standard conversion." -Level Debug
}
else {
    Write-BuildLog "Model processing disabled." -Level Debug
}

Write-BuildLog "Model configuration initialization completed successfully." -Level Success

# ============================================================================
# BLOCK 12 — DOCUMENT DISCOVERY
# ============================================================================
Write-BuildLog "BLOCK 12 - DOCUMENT DISCOVERY" -Level Debug

$Documents = @()

# SINGLE DOCUMENT MODE: Process the target document directly
if (-not [string]::IsNullOrWhiteSpace($Document)) {
    $SourceDocumentPath = Join-Path $DocBasePath $Document
    Write-BuildLog "Single document target specified: $SourceDocumentPath" -Level Debug

    if (Test-Path -LiteralPath $SourceDocumentPath) {
        $FileItem = Get-Item -LiteralPath $SourceDocumentPath

        if (-not $TargetType) {
            if ($Document -match '[\\/]reference[\\/]') { $TargetType = "reference" }
            else { $TargetType = "guides" }
        }

        $FileItem | Add-Member -MemberType NoteProperty -Name TargetType -Value $TargetType -Force
        $Documents = @($FileItem)
        Write-BuildLog "Successfully queued single document: $($FileItem.Name)" -Level Debug
    }
    else {
        Write-BuildLog "CRITICAL: Specified document path does not exist:`n$SourceDocumentPath" -Level Error
        return
    }
}
# BATCH MODE: Scan guides\ and reference\ inside site-documentation base path
else {
    Write-BuildLog "No specific document target provided. Scanning repository guides\ and reference\ folders..." -Level Debug
    $AllDocuments = @()

    foreach ($Folder in @("guides", "reference")) {
        $FolderPath = Join-Path $DocBasePath "$SiteName\$Folder"
        if (Test-Path -LiteralPath $FolderPath) {
            $Files = Get-ChildItem -Path $FolderPath -Filter "*.docx" -File
            if ($Files) {
                Write-BuildLog "Found $($Files.Count) document(s) in $Folder\" -Level Debug
                $AllDocuments += $Files
            }
        }
    }

    if (-not $AllDocuments) {
        Write-BuildLog "No .docx source files found in $DocBasePath\$SiteName\" -Level Warning
        return
    }

    $Documents = $AllDocuments | ForEach-Object {
        $_ | Add-Member -MemberType NoteProperty -Name TargetType -Value $_.Directory.Name -PassThru
    }
}

Write-BuildLog "Document discovery completed successfully." -Level Success

# ============================================================================
# BLOCK 13 — REPORT DISCOVERED DOCUMENTS
# ============================================================================
Write-BuildLog "BLOCK 13 - DISCOVERED DOCUMENTS" -Level Debug

if (-not $Documents) {
    Write-BuildLog "No DOCX documents selected or discovered for processing." -Level Warning
    return
}

foreach ($DocItem in $Documents) {
    Write-BuildLog "Queued Document: $($DocItem.FullName)" -Level Debug
}

Write-BuildLog "Document selection and queuing completed successfully." -Level Success

# ============================================================================
# BLOCK 14 — PIPELINE EXECUTION (MAIN ORCHESTRATION)
# ============================================================================
Write-BuildLog "BLOCK 14 - PIPELINE EXECUTION" -Level Debug
Write-BuildLog "Target Web Directory: $DeployRoot" -Level Debug

foreach ($DocItem in $Documents) {
    $BaseName  = $DocItem.BaseName
    $DocPath   = $DocItem.FullName

    # -------------------------------------------------------------------------
    # TITLE TRANSFORMATION (Remove leading numbers, strip hyphens, Title Case)
    # -------------------------------------------------------------------------
    $CleanTitle = $BaseName -replace '^\d+[-_]?', '' -replace '[-_]', ' '
    $CleanTitle = (Get-Culture).TextInfo.ToTitleCase($CleanTitle.ToLower())
    # -------------------------------------------------------------------------

    if ($DocPath -match '[\\/]guides[\\/]') { $TargetType = "guides" }
    elseif ($DocPath -match '[\\/]reference[\\/]') { $TargetType = "reference" }
    else { $TargetType = "guides" }

    $MarkdownOut  = Join-Path $ProjectRoot "build\output\${BaseName}.md"
    $WorkingMedia = Join-Path $ProjectRoot "build\working\$BaseName"
    $HtmlBuildOut = Join-Path $ProjectRoot "build\output\${BaseName}.html"

    $WebsiteHtml  = Join-Path $DeployRoot "$SiteName\$TargetType\${BaseName}.html"
    $WebsiteMedia = Join-Path $DeployRoot "$SiteName\$TargetType\$BaseName\media"

    Write-BuildLog "Processing Document: $DocPath" -Level Debug
    Write-BuildLog "  Category:    $TargetType" -Level Debug
    Write-BuildLog "  Markdown:    $MarkdownOut" -Level Debug
    Write-BuildLog "  Local Media: $WorkingMedia" -Level Debug
    Write-BuildLog "  Deploy HTML: $WebsiteHtml" -Level Debug
    Write-BuildLog "  Clean Title: $CleanTitle" -Level Debug

    # STAGE 1: DOCX -> Markdown
    Write-BuildLog "STAGE 1 - DOCX -> MARKDOWN" -Level Debug
    Convert-DocxToMarkdown -InputDocx $DocPath -OutputMarkdown $MarkdownOut -AssetDirectory $WorkingMedia
    Write-BuildLog "DOCX to Markdown conversion completed." -Level Debug

    # STAGE 2: Normalize Markdown Image Links
    Write-BuildLog "STAGE 2 - MARKDOWN MEDIA NORMALIZATION" -Level Debug
    if (Get-Command Normalize-MarkdownMedia -ErrorAction SilentlyContinue) {
        Normalize-MarkdownMedia -MarkdownFile $MarkdownOut -BaseName $BaseName
        Write-BuildLog "Markdown image references normalized." -Level Debug
    } else {
        Write-BuildLog "Normalize-MarkdownMedia function skipped (not loaded)." -Level Debug
    }

    # STAGE 3: Markdown -> HTML
    Write-BuildLog "STAGE 3 - MARKDOWN -> HTML" -Level Debug
    $LuaFilter    = Join-Path $FiltersDir "collapsible-downloads.lua"
    $TemplateFile = Join-Path $TemplatesDir "template.html"

    Convert-MarkdownToHtml `
        -MarkdownFile $MarkdownOut `
        -OutputHtml $HtmlBuildOut `
        -TemplateFile $TemplateFile `
        -LuaFilter $LuaFilter `
        -Title $CleanTitle

# STAGE 4: HTML Normalization
    Write-BuildLog "STAGE 4 - HTML NORMALIZATION" -Level Debug
    if (Get-Command Normalize-Html -ErrorAction SilentlyContinue) {
        Normalize-Html -HtmlFile $HtmlBuildOut -BaseName $BaseName
        Write-BuildLog "HTML post-processing normalization complete." -Level Debug
    }

        # Keep the reusable tool bundle link in the generated installation guide.
        if ($BaseName -eq "1-home-lab-install-procedure") {
                $GeneratedHtml = Get-Content -LiteralPath $HtmlBuildOut -Raw -Encoding UTF8
                if ($GeneratedHtml -notmatch "home-lab-tools\.zip") {
                        $ToolBundleLink = @'
        <div class="download-container" style="margin-bottom: 1.5rem;">
            <details class="collapsible-download-box">
                <summary class="box-header"><span class="folder-icon">TOOLS</span> Home Lab Tools Bundle</summary>
                <div class="box-body">
                    <p>The complete build toolkit is packaged for extraction over a <code>home-lab-tools</code> directory. It includes the build script, component loader, support scripts, prompts, filters, and HTML templates.</p>
                    <a href="../assets/home-lab-tools.zip" class="download-btn" download>Download Home Lab Tools</a>
                </div>
            </details>
        </div>
'@
                        $GeneratedHtml = $GeneratedHtml.Replace('<div class="title-banner"', $ToolBundleLink + "`r`n    " + '<div class="title-banner"')
                        Set-Content -LiteralPath $HtmlBuildOut -Value $GeneratedHtml -Encoding UTF8
                        Write-BuildLog "Added home-lab-tools.zip link to generated installation guide." -Level Debug
                }
        }

    # STAGE 5: Prepare Deployment Directories
    Write-BuildLog "STAGE 5 - PREPARE DEPLOYMENT DIRECTORIES" -Level Debug
    $null = New-Item -ItemType Directory -Path (Split-Path $WebsiteHtml) -Force
    $null = New-Item -ItemType Directory -Path $WebsiteMedia -Force
    Write-BuildLog "Target web directories verified." -Level Debug

    # STAGE 6: Deploy HTML & Media Assets
    Write-BuildLog "STAGE 6 - DEPLOYMENT" -Level Debug
    Copy-Item -Path $HtmlBuildOut -Destination $WebsiteHtml -Force
    Write-BuildLog "HTML deployed to: $WebsiteHtml" -Level Debug

    $ExtractedMedia = Join-Path $WorkingMedia "media"
    if (Test-Path -LiteralPath $ExtractedMedia) {
        $MediaFiles = Get-ChildItem -Path $ExtractedMedia -File
        foreach ($File in $MediaFiles) {
            Copy-Item -Path $File.FullName -Destination (Join-Path $WebsiteMedia $File.Name) -Force
            Write-BuildLog "  Deployed Media: $($File.Name)" -Level Debug
        }
        Write-BuildLog "Media assets deployed to: $WebsiteMedia" -Level Debug
    }

    # STAGE 7: Package Document Archive (.ZIP)
    Write-BuildLog "STAGE 7 - ARCHIVE PACKAGING" -Level Debug
    $ArchiveDir = Join-Path $ProjectRoot "assets\archives"
    $PkgDir     = Join-Path $ProjectRoot "build\working\packages\$BaseName"

    $null = New-Item -ItemType Directory -Path $ArchiveDir -Force
    $null = New-Item -ItemType Directory -Path $PkgDir -Force

    $PdfSource = Join-Path $DocBasePath "$SiteName\$TargetType\${BaseName}.pdf"
    if (Test-Path -LiteralPath $PdfSource) {
        Copy-Item -Path $PdfSource -Destination (Join-Path $PkgDir "${BaseName}.pdf") -Force
    }

    if (Test-Path -LiteralPath $ExtractedMedia) {
        Copy-Item -Path "$ExtractedMedia\*" -Destination (Join-Path $PkgDir "media") -Recurse -Force
    }

    $ZipOutputPath = Join-Path $ArchiveDir "${BaseName}.zip"
    Compress-Archive -Path "$PkgDir\*" -DestinationPath $ZipOutputPath -Force
    Write-BuildLog "Archive created: $ZipOutputPath" -Level Debug
}

Write-BuildLog "Document build pipeline completed successfully." -Level Success
# ============================================================================
# BLOCK 15 — TOOL BUNDLE, DEPLOYMENT CLEANUP & ASSET PROCESSING
# ============================================================================
Write-BuildLog "BLOCK 15 - TOOL BUNDLE, DEPLOYMENT CLEANUP & ASSET PROCESSING" -Level Debug

# Build a self-contained bundle that can be extracted over a home-lab-tools directory.
$ToolBundleName = "home-lab-tools"
$ToolStageDir   = Join-Path $ProjectRoot "build\working\$ToolBundleName"
$ToolDownloadDir = Join-Path $ProjectRoot "assets\downloads"
$ToolZipPath    = Join-Path $ToolDownloadDir "$ToolBundleName.zip"
$WebsiteToolDir = Join-Path $DeployRoot "$SiteName\assets"
$WebsiteToolZip = Join-Path $WebsiteToolDir "$ToolBundleName.zip"

if (Test-Path -LiteralPath $ToolStageDir) {
    Remove-Item -LiteralPath $ToolStageDir -Recurse -Force
}

$null = New-Item -ItemType Directory -Path $ToolStageDir -Force
$null = New-Item -ItemType Directory -Path $ToolDownloadDir -Force
$null = New-Item -ItemType Directory -Path $WebsiteToolDir -Force

Copy-Item -LiteralPath (Join-Path $ProjectRoot "build.ps1") -Destination $ToolStageDir -Force
Copy-Item -LiteralPath (Join-Path $ProjectRoot "README.md") -Destination $ToolStageDir -Force

foreach ($ToolDirectoryName in @("config", "filters", "prompts", "scripts", "support", "templates")) {
    $ToolSourceDir = Join-Path $ProjectRoot $ToolDirectoryName
    $ToolTargetDir = Join-Path $ToolStageDir $ToolDirectoryName
    $null = New-Item -ItemType Directory -Path $ToolTargetDir -Force
    Copy-Item -Path (Join-Path $ToolSourceDir "*") -Destination $ToolTargetDir -Recurse -Force
}

# component-loader.js belongs to the website, but is required by the generated pages.
$ComponentLoader = Join-Path $DeployRoot "scripts\component-loader.js"
if (-not (Test-Path -LiteralPath $ComponentLoader)) {
    throw "Required website component loader not found: $ComponentLoader"
}
Copy-Item -LiteralPath $ComponentLoader -Destination (Join-Path $ToolStageDir "scripts\component-loader.js") -Force

if (Test-Path -LiteralPath $ToolZipPath) {
    Remove-Item -LiteralPath $ToolZipPath -Force
}
Compress-Archive -Path (Join-Path $ToolStageDir "*") -DestinationPath $ToolZipPath -Force
Copy-Item -LiteralPath $ToolZipPath -Destination $WebsiteToolZip -Force
Write-BuildLog "Tool bundle created: $ToolZipPath" -Level Success
Write-BuildLog "Tool bundle deployed: $WebsiteToolZip" -Level Debug

# Remove generated and misplaced deployment artifacts after the build is complete.
if (Test-Path -LiteralPath (Join-Path $ProjectRoot "build\output")) {
    Get-ChildItem -LiteralPath (Join-Path $ProjectRoot "build\output") -Force | Remove-Item -Recurse -Force
}

$DeployedFiguresDir = Join-Path $DeployRoot "$SiteName\figures"
if (Test-Path -LiteralPath $DeployedFiguresDir) {
    Remove-Item -LiteralPath $DeployedFiguresDir -Recurse -Force
    Write-BuildLog "Removed obsolete deployed figures directory: $DeployedFiguresDir" -Level Debug
}

$WebsiteScriptsDir = Join-Path $DeployRoot "scripts"
Get-ChildItem -LiteralPath $WebsiteScriptsDir -File -Force |
    Where-Object { $_.Name -ne "component-loader.js" } |
    Remove-Item -Force
Write-BuildLog "Removed misplaced website scripts; retained component-loader.js." -Level Debug

Write-BuildLog "Asset audit and cleanup completed successfully." -Level Success
