[CmdletBinding()]
param()

$ErrorActionPreference = "SilentlyContinue"
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "   HOME-LAB MODEL AUTHENTICATION AUDIT       " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

$providers = @(
    @{ Name = "Gemini";     EnvVar = "GEMINI_API_KEY";     TestType = "CLI" },
    @{ Name = "Groq";       EnvVar = "GROQ_API_KEY";       TestType = "Rest"; Uri = "https://api.groq.com/openai/v1/chat/completions"; Model = "openai/gpt-oss-20b" },
    @{ Name = "OpenRouter"; EnvVar = "OPENROUTER_API_KEY"; TestType = "Rest"; Uri = "https://openrouter.ai/api/v1/chat/completions"; Model = "nvidia/nemotron-3-ultra-550b-a55b:free" }
)

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

foreach ($p in $providers) {
    Write-Host -NoNewline "Checking provider [$($p.Name)]... "

    if ($p.TestType -eq "CLI") {
        $cmd = Get-Command "gemini" -ErrorAction SilentlyContinue
        if ($cmd) {
            $geminiKey = [System.Environment]::GetEnvironmentVariable("GEMINI_API_KEY", "User")
            if (-not $geminiKey) { $geminiKey = $env:GEMINI_API_KEY }
            if ($geminiKey) { $geminiKey = $geminiKey.Trim() }

            if ($geminiKey) { 
                Write-Host "[OK] CLI Installed. Key active." -ForegroundColor Green 
            } else { 
                Write-Host "[OK] CLI Installed, but environment variable not set." -ForegroundColor Yellow 
            }
        } else {
            Write-Host "[FAIL] Gemini CLI missing from PATH." -ForegroundColor Red
        }
        continue
    }

    $rawKey = [System.Environment]::GetEnvironmentVariable($p.EnvVar, "User")
    if (-not $rawKey) { $rawKey = [System.Environment]::GetEnvironmentVariable($p.EnvVar, "Process") }
    
    if (-not $rawKey) {
        Write-Host "[FAIL] Missing environment variable '$($p.EnvVar)'." -ForegroundColor Red
        continue
    }
    
    $key = $rawKey.Trim()
    Write-Host "(Key set) " -NoNewline -ForegroundColor DarkGray

    $headers = @{ "Authorization" = "Bearer $key" }
    if ($p.Name -eq "OpenRouter") {
        $headers["HTTP-Referer"] = "https://smart-home-edge-systems.us"
        $headers["X-Title"] = "Home Lab Diagnostic"
    }

    $body = @{
        model = $p.Model
        messages = @(@{ role = "user"; content = "ping" })
        max_tokens = 5
    } | ConvertTo-Json

    try {
        $response = Invoke-WebRequest -Uri $p.Uri -Method Post -Headers $headers -Body $body -ContentType "application/json" -TimeoutSec 10 -UseBasicParsing
        if ($response.StatusCode -eq 200) {
            Write-Host "[OK] API Authenticated & Responding." -ForegroundColor Green
        } else {
            Write-Host "[WARN] Connected, but status code: $($response.StatusCode)" -ForegroundColor Yellow
        }
    }
    catch {
        $stream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream)
        $errText = $reader.ReadToEnd()
        $statusCode = [int]$_.Exception.Response.StatusCode

        if ($statusCode -eq 429) {
            Write-Host "[QUOTA EXCEEDED] Rate limit or daily token cap reached." -ForegroundColor Yellow
        }
        elseif ($statusCode -eq 401) {
            Write-Host "[FAIL] Invalid API Key (HTTP 401)." -ForegroundColor Red
        }
        else {
            Write-Host "[FAIL] HTTP Error $statusCode" -ForegroundColor Red
        }
    }
}
Write-Host "=============================================" -ForegroundColor Cyan