﻿Home Lab Documentation Build Pipeline
Maintained for Smart-Home-Edge-Systems.us by ChatGPT

Release: 1.1 — Enhanced INCLUDETEXT support and robust code handling.

# ⚙️ Home Lab Documentation Build Pipeline

**Automated Word-to-Web Publishing Engine with Dynamic Code & Snippet Integration**

[![Release](https://img.shields.io/badge/Release-1.1-emerald?style=for-the-badge)](https://github.com/Smart-Home-Edge-Systems)
[![PowerShell](https://img.shields.io/badge/PowerShell-7.x-blue?style=for-the-badge&logo=powershell)](https://github.com/PowerShell/PowerShell)
[![Pandoc](https://img.shields.io/badge/Pandoc-3.x-orange?style=for-the-badge&logo=pandoc)](https://pandoc.org/)
[![Status](https://img.shields.io/badge/Pipeline-Active-success?style=for-the-badge)]()

Purpose: Provides a repeatable documentation build pipeline for the Home Lab project that converts Word documents (.docx) to publish-ready HTML websites with support for INCLUDETEXT fields for dynamic script content.

## Current Status - Release 1.1 ✅

* ✅ **Core Build Pipeline**: `build.ps1` fully functional with DOCX → Markdown → HTML conversion
* ✅ **Logging & Verbose Output**: `build.ps1` fully functional with DOCX → Markdown → HTML conversion
* ✅ **Modular Library Structure**: Functions extracted into dedicated scripts inside `scripts/` (`common.ps1`, `document-discovery.ps1`, `html-functions.ps1`, `pandoc-functions.ps1`, `model-functions.ps1`)
* ✅ **INCLUDETEXT Support**: Script and text snippet content properly integrated from external files
* ✅ **Custom Style Processing**: Both `"Code"` (green) and `"TextBlock"` (blue) styles correctly handled
* ✅ **PDF Integration**: PDF export to `guides/project_pdfs/` with automatic archive packaging
* ✅ **PowerShell Compliance**: All functions use approved PowerShell verbs
* ✅ **Enhanced Lua Filter**: Robust handling of mixed Word formatting styles
* ✅ **HTML Post-Processing**: Perl variable removal and code block normalization
* ✅ **Media Deployment**: Automatic media extraction, path normalization, and website deployment
* ✅ **Archive Packaging**: ZIP bundles with PDFs and media in `assets/archives/`
* ✅ **Advanced Word Macros**: Comprehensive automation in `support/WordMacros.vba`

## Release Roadmap & Forward Work Items

### Release 1.2 - Production Readiness (Recommended Next Release)
*Priority: HIGH - Focus on production deployment readiness*

1. **Build Validation Stage** ⚡ *High Priority*
   - [ ] Implement automated post-build verification
   - [ ] UTF-8 (No BOM) encoding validation
   - [ ] Image path resolution checks
   - [ ] Missing link detection
   - [ ] Prevent absolute Windows paths (C:\Users\...) in HTML
   - [ ] Estimated time: 1-2 sessions (with debug buffer)

2. **Clean Environment Testing** ⚡ *High Priority*
   - [ ] Create build target cleanup scripts
   - [ ] Implement DELETE build/ functionality
   - [ ] Test clean builds from scratch
   - [ ] Verify no file lock issues
   - [ ] Estimated time: 1 session (with debug buffer)

3. **Logging & Verbose Output** 📝 *Medium Priority*
   - [ ] Create build summary reports
   - [ ] Estimated time: 1 session

### Release 1.3 - Content Enhancement
*Priority: MEDIUM - Improve user experience and content quality*

4. **File Naming Conventions** 📁 *Medium Priority*
   - [ ] Rename generic outputs (image1.png) to descriptive names
   - [ ] Use caption-based naming (proxmox-install.png)
   - [ ] Update media reference handling in build script
   - [ ] Estimated time: 1-2 sessions

5. **Title Cleanup** 🎯 *Medium Priority*
   - [ ] Transform source titles to clean HTML headers
   - [ ] Convert "1 - Home Lab Install Procedure" → "HOME LAB INSTALL PROCEDURE"
   - [ ] Implement title normalization in HTML post-processing
   - [ ] Estimated time: 1 session

6. **Archive Download Structure** 📦 *Medium Priority*
   - [ ] Consolidate HTML download links to single combined zip file per document
   - [ ] Remove multiple download entries in HTML
   - [ ] Update archive packaging logic for single website zip files
   - [ ] Estimated time: 1 session

7. **Block Numbering & Comments** 📚 *Low Priority*
   - [ ] Establish single authoritative block lists
   - [ ] Expand usage documentation in README.md
   - [ ] Create block numbering standard
   - [ ] Estimated time: 1 session

### Release 1.4 - Advanced Features
*Priority: LOW - Nice-to-have features for future*

8. **External Image Referencing** 🖼️ *Low Priority*
   - [ ] Transition image references to external assets
   - [ ] Similar to text snippet architecture
   - [ ] Update media handling functions
   - [ ] Estimated time: 2-3 sessions

9. **Google Analytics & Ads** 📊 *Low Priority*
   - [ ] Verify Analytics activation
   - [ ] Evaluate optional ad integrations
   - [ ] Add tracking code to template.html
   - [ ] Estimated time: 1 session

10. **AI Reference Generator** 🤖 *Experimental*
   - [x] Implement optional command-line flag for AI analysis
   - [ ] Build end-of-document reference summaries
   - [x] Add -UseAIReview parameter
   - [ ] Implement Gemini CLI integration blocks (BLOCKS 16-20)
   - [ ] Estimated time: 2-3 sessions (requires API testing)

## Session Planning for Free Tier

**Recommended Session Strategy:**
- **Small focused tasks**: Each release item is sized for 1-2 sessions max
- **Debug buffer included**: All estimates include 20-30% extra time for debugging
- **Parallel processing**: Where possible, test on single document before full pipeline
- **Incremental validation**: Test each change before moving to next item

**Suggested Order (Free Tier Optimized):**
1. Release 1.2 Items 1-2 (Build Validation + Clean Environment) - 2-3 sessions
2. Release 1.2 Item 3 (Logging) - 1 session
3. Release 1.3 Items 4-5 (File Naming + Title Cleanup) - 2-3 sessions
4. Release 1.3 Item 6 (Archive Download Structure) - 1 session
5. Release 1.3 Item 7 (Block Numbering) - 1 session
6. Release 1.4 Items 8-10 (Advanced Features) - As needed

**Total Estimated Time:** 8-11 sessions for complete Release 1.2-1.3 pipeline

Complete Workflow Pipeline
Phase 1: Word Document Preparation ✅
1.1 Document Structure Requirements ✅
✅ Store source documents in guides/ (for guides) or reference/ (for reference materials).
✅ Use consistent file naming: document-name.docx.
✅ Ensure INCLUDETEXT fields reference scripts in guides/project_scripts/.
✅ Store imported text files in guides/project_snippets/ for text-based content.
✅ PDF exports should be placed in guides/project_pdfs/.
✅ **Encoding Standard**: All external files must be UTF-8 (No BOM) - standard for cross-platform compatibility
✅ **Text Editor**: Use Notepad++ for editing external files to maintain proper encoding
✅ **File Format**: Set Notepad++ encoding to "UTF-8 (without BOM)" for all external text files

1.1.1 Word Document Formatting Steps ✅
✅ **How to Set the Title Inside Word (.docx):**
✅ 1. Open your master file in Microsoft Word
✅ 2. Make sure all Titles are set to Heading 1
✅ 3. Make sure all first level of indentation is set to Heading 2
✅ 4. Make sure all second level of indentation is set to Heading 3
✅ 5. Make sure all captions and subtitles are set to Heading 4
✅ 6. Make sure all INCLUDEFILES "TextBlocks" are set to TextBlock
✅ 7. Make sure all INCLUDEFILES "Code" are set to Code
✅ 8. Run the Macro after saving the document to update all fields and export a valid PDF

1.2 Word Style Guidelines ✅
✅ Valid Custom Styles:
✅ "Code" style: Light Green background, monospace font; used for code blocks, commands, programming code, and scripts.
✅ "TextBlock" style: Light Blue background, standard font; used for informational text blocks, configuration examples, and setup instructions.
✅ Style Usage Guidelines: Both styles are valid and will be properly processed by the build pipeline.

1.3 INCLUDETEXT Field Setup ✅
✅ Scripts Example:
✅ Plaintext
{ INCLUDETEXT "C:\\Users\\barne\\Documents\\HomeAssistant\\Proxmox\\Web-Design\\home-lab-project\\guides\\project_scripts\\scriptname.sh" \* MERGEFORMAT }
✅ Text Snippets Example:
✅ Plaintext
{ INCLUDETEXT "C:\\Users\\barne\\Documents\\HomeAssistant\\Proxmox\\Web-Design\\home-lab-project\\guides\\project_snippets\\config-snippet.txt" \* MERGEFORMAT }
✅ Best Practices:
✅ Apply Code style to script files and TextBlock style to text snippets.
✅ Ensure target files exist in project_scripts/ or project_snippets/.
✅ Test fields by updating the source file and pressing Alt + F9 in Word to refresh.

1.4 File Organization ✅
✅ guides/project_scripts/: Shell scripts (.sh), configuration scripts, and automation scripts.
✅ guides/project_snippets/: Configuration examples, setup instructions, and reference material.

1.5 Code Block Placement ✅
✅ Scripts Structure:
✅ Plaintext
## Script Name
Code 1: scriptname.sh
[INCLUDETEXT field with Code style pointing to project_scripts/]
✅ Text Snippets Structure:
✅ Plaintext
## Configuration Section
[INCLUDETEXT field with TextBlock style pointing to project_snippets/]

Phase 2: Word Macro Automation ✅
2.1 Advanced Word Macros ✅
✅ **Location**: support/WordMacros.vba
✅ **Main Macro**: SyncPublishAndSaveDoc()
✅ **Features**:
✅ - Smart path normalization for INCLUDETEXT and INCLUDEPICTURE fields
✅ - Automatic external content updates
✅ - TOC and Figure table updates
✅ - TextBlock and Code style processing (tabs to spaces, paragraph marks to soft line breaks)
✅ - Automatic PDF export to guides/project_pdfs/
✅ - Comprehensive error handling

2.2 Macro Implementation Instructions ✅
✅ **To install macros in Word template**:
✅ 1. Open Word (Alt+F11 to open VBA editor)
✅ 2. Insert the content from support/WordMacros.vba into your Normal.dotm or document template
✅ 3. Save and close the VBA editor
✅ 4. Run SyncPublishAndSaveDoc() from the Macros list (Alt+F8)

2.3 Macro Execution Workflow ✅
✅ **Before Build Pipeline**:
✅ 1. Format document with proper heading styles (Heading 1-4)
✅ 2. Apply Code style to INCLUDETEXT script content
✅ 3. Apply TextBlock style to INCLUDETEXT text snippet content
✅ 4. Run SyncPublishAndSaveDoc() macro
✅ 5. Macro automatically:
✅    - Normalizes all INCLUDETEXT and INCLUDEPICTURE paths
✅    - Updates all external content
✅    - Processes text formatting
✅    - Exports PDF to guides/project_pdfs/
✅ 6. Proceed with build.ps1 execution

Phase 3: PDF Export ✅
3.1 PDF Export Process ✅
✅ Export Word document to PDF manually.
✅ Save PDF to guides/project_pdfs/ using the naming format document-name.pdf.
✅ The pipeline will automatically append these to output archives.

3.2 PDF Export Settings ✅
✅ Standard PDF export (no special encoding required).
✅ Include bookmarks and document structure where applicable.

Phase 4: Build Pipeline Execution ✅
4.1 Pipeline Overview ✅
✅ build.ps1 orchestrates the execution flow:
✅ DOCX → Markdown → HTML → Website Deployment → Media Processing → Archive Packaging

4.2 Commands & Usage ✅
✅ PowerShell
✅ # Basic Build
✅ cd "C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design\home-lab-project"
✅ .\build.ps1
✅ # Single Document Build
✅ .\build.ps1 -DocBaseName "1-home-lab-install-procedure"
✅ # Target Folder Specification
✅ .\build.ps1 -DocBaseName "example-document" -TargetFolder "guides"

4.3 Pipeline Stages ✅
✅ DOCX → Markdown: Converts DOCX using Pandoc, extracts media, and parses INCLUDETEXT fields.
✅ Markdown → HTML: Converts Markdown to HTML with Pandoc Lua filters and custom templates.
✅ HTML Normalization: Strips Perl-style variable substitutions (e.g., $CodeIndex++) and standardizes block numbering.
✅ Website Deployment: Copies compiled HTML to production web directories.
✅ Media Processing: Moves extracted media to permanent asset paths.
✅ Archive Packaging: Compiles .zip packages containing PDFs and assets into assets/archives/.

4.4 Output Locations ✅
✅ Working Directory: build/working/<document-name>/
✅ Compiled Output: build/output/<document-name>.html, build/output/<document-name>.md
✅ Web Directory: smart-home-edge-systems/home-lab/guides/<document-name>.html
✅ Archives: assets/archives/<document-name>.zip

4.5 Future Pipeline Work (See Release Roadmap Above)
📋 Google Analytics & Ads: Verify Analytics activation; evaluate optional ad integrations.
📋 External Image Referencing: Transition image references to external assets similar to text snippets.
📋 File Naming Conventions: Rename generic outputs (image1.png) to caption-based descriptive filenames (proxmox-install.png).
📋 Title Cleanup: Transform source titles like "1 - Home Lab Install Procedure" to clean HTML header titles (HOME LAB INSTALL PROCEDURE).
📋 Logging & Verbose Output: Implement .\build.ps1 -Detailed logging output.
📋 Block Numbering & Comments: Establish single authoritative block lists and expand usage docs in README.md.
📋 Build Validation Stage: Automate post-build verification (UTF-8 checks, image path resolution, missing links, preventing absolute Windows paths like C:\Users\...).
📋 Clean Environment Testing: Build target cleanup execution scripts (DELETE build/, clean runs).
📋 AI Reference Generator: Implement an optional command-line flag to invoke AI analysis for building end-of-document reference summaries.

Phase 5: Quality Verification ✅
5.1 HTML Output Checklist ✅
✅ INCLUDETEXT content rendered cleanly.
✅ Code blocks structured with <pre><code>.
✅ Image paths resolve correctly with intact navigation and TOC links.

Project Structure ✅
git-Repositories - C:\Users\barne\Documents\HomeAssistant\Proxmox\Web-Design
 ✅├─ home-lab-project/
 ✅│   ├── build.ps1                     # Main orchestration script
 ✅│   ├── README.md                     # Documentation and Coding Constraints
 ✅│   ├── CHANGELOG.md                  # Version history
 ✅│   ├── support/                      # Supporting test scripts, files and macros
 ✅│   │   └── WordMacros.vba            # Advanced Word automation macros
 ✅│   ├── assets/
 ✅│   │   ├── figures/                  # Downloyable images/media
 ✅│   │   └── archives/                 # Downloyable document bundles (.zip)
 ✅│   ├── scripts/                      # PowerShell utilities (common, discovery, pandoc, model, html, asset)
 ✅│   ├── filters/                      # Pandoc Lua filters (collapsible-downloads.lua)
 ✅│   ├── templates/                    # HTML layout templates (template.html)
 ✅│   ├── prompts/                      # Model prompts
 ✅│   ├── build/                        # Temp Output, working files, and logs
 ✅├─ smart-home-edge-systems/           # Web production root (referenced as home-lab-project/../ to keep VSCode Go Live working)
 ✅├─ site-documentation/
 ✅│   ├─home-lab/                         # 1st project     # One of many directories
 ✅│   │ ├─ guides/                        # Source Word documents
 ✅│   │ │   ├── 1-home-lab-install-procedure.docx    # One of many files
 ✅│   │ │   ├── project_scripts/          # INCLUDETEXT script files (e.g., PiHolePost.sh)
 ✅│   │ │   ├── project_snippets/         # INCLUDETEXT text files (e.g., config-snippet.txt)
 ✅│   │ │   └── project_pdfs/             # PDF export archive targets
 ✅│   │ ├── reference/                    # Material references
 ✅│   │ │   ├── 1-Installing NUT on Windows.docx    # One of many files
 ✅│   │ │   ├── project_scripts/          # INCLUDETEXT script files 
 ✅│   │ │   ├── project_snippets/         # INCLUDETEXT text files 
 ✅│   │ │   └── project_pdfs/             # PDF export archive targets
 ✅│   ├─r-d/                              # multiple projects follow

Key Functions & Configuration ✅
✅ Convert-DocxToMarkdown: Converts DOCX to Markdown with media extraction and lock-bypassing.
✅ Update-MarkdownMediaReferences: Normalizes path references for Windows/Linux compatibility.
✅ Convert-MarkdownToHtml: Compiles Markdown through Pandoc using templates and custom Lua filters.
✅ Get-CssRelPath: Returns site-relative path /styles/global.css.
✅ templates/template.html: Master HTML shell and CSS styling.
✅ filters/collapsible-downloads.lua: Transforms Heading 5 into collapsible elements and processes custom styles.

Troubleshooting & Maintenance ✅
✅ Pandoc Not Found: Install via winget install pandoc.
✅ Missing Script Functions: Verify all dependencies listed in $RequiredScripts exist in scripts/.
✅ INCLUDETEXT Fails to Load: Ensure file paths match, styles are applied, and fields are refreshed (Alt + F9).
✅ Updating Documents: Edit DOCX → Update target script/snippet → Refresh fields → Re-export PDF → Run build.ps1.
✅ **Encoding Issues**: Use Notepad++ with "UTF-16 LE BOM" encoding for all external text files (scripts, snippets, etc.)

## Appendices

### Advanced Pipeline Features (Future Implementation)

These advanced features are planned for future releases but are not currently implemented in the main build.ps1:

#### AI-Powered Document Review (Release 1.4)
📋 Optional integration with Gemini CLI for automated document review
📋 Features include: content validation, technical accuracy checking, reference generation
📋 Usage: .\build.ps1 -UseAIReview (framework in place, full implementation pending)
📋 Status: Framework implemented in build.ps1 BLOCK 15, implementation blocks 16-20 pending
📋 Estimated implementation: 2-3 sessions

#### Advanced Analytics (Release 1.4)
📋 Google Analytics integration for website usage tracking
📋 Optional ad integration for monetization
📋 Estimated implementation: 1 session

